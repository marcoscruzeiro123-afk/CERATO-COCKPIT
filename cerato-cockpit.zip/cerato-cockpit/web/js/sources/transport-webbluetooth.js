/* Transporte Web Bluetooth (BLE).
 * ATENÇÃO: só funciona com adaptadores ELM327 que usam Bluetooth Low Energy (BLE / "4.0"),
 * em navegadores com Web Bluetooth (Chrome/Android, contexto seguro: https ou localhost).
 * Adaptadores ELM327 baratos "Bluetooth 2.x" usam SPP clássico e NÃO funcionam por aqui — use a ponte Android. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  CC.transports = CC.transports || {};

  const SERVICES = [
    '0000fff0-0000-1000-8000-00805f9b34fb',
    '0000ffe0-0000-1000-8000-00805f9b34fb',
    '000018f0-0000-1000-8000-00805f9b34fb',
    'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
  ];

  class WebBtTransport {
    constructor() { this.onData = null; this.onClose = null; this.alive = false; this.dev = null; this.wr = null; }
    async connect(_dev, interactive) {
      if (!navigator.bluetooth) throw new Error('Web Bluetooth indisponível neste navegador');
      if (!interactive) throw new Error('Toque em "Conectar" para escolher o adaptador (exigência do navegador)');
      this.dev = await navigator.bluetooth.requestDevice({
        filters: [{ namePrefix: 'OBD' }, { namePrefix: 'ELM' }, { namePrefix: 'V-LINK' }, { namePrefix: 'vLinker' }, { namePrefix: 'Vgate' }, ...SERVICES.map((s) => ({ services: [s] }))],
        optionalServices: SERVICES,
      });
      this.dev.addEventListener('gattserverdisconnected', () => { this.alive = false; if (this.onClose) this.onClose('Bluetooth desconectado'); });
      const server = await this.dev.gatt.connect();
      let rx = null, tx = null;
      for (const sid of SERVICES) {
        let svc; try { svc = await server.getPrimaryService(sid); } catch (e) { continue; }
        const chars = await svc.getCharacteristics();
        for (const c of chars) {
          if (!rx && (c.properties.notify || c.properties.indicate)) rx = c;
          if (!tx && (c.properties.write || c.properties.writeWithoutResponse)) tx = c;
        }
        if (rx && tx) break;
      }
      if (!rx || !tx) throw new Error('Adaptador sem serviço serial BLE reconhecido');
      this.wr = tx;
      await rx.startNotifications();
      const dec = new TextDecoder();
      rx.addEventListener('characteristicvaluechanged', (e) => { if (this.onData) this.onData(dec.decode(e.target.value)); });
      this.alive = true;
    }
    write(s) {
      const data = new TextEncoder().encode(s);
      const w = this.wr, nores = w.properties.writeWithoutResponse;
      (async () => {
        for (let i = 0; i < data.length; i += 20) {
          const part = data.slice(i, i + 20);
          if (nores && w.writeValueWithoutResponse) await w.writeValueWithoutResponse(part); else await w.writeValue(part);
        }
      })().catch((e) => { if (this.onClose) this.onClose(String(e)); });
    }
    close() { this.alive = false; try { if (this.dev && this.dev.gatt.connected) this.dev.gatt.disconnect(); } catch (e) { /* ignora */ } }
  }

  CC.transports.webbt = {
    id: 'webbt',
    label: 'Web Bluetooth (somente BLE)',
    available: () => typeof navigator !== 'undefined' && !!navigator.bluetooth,
    needsGesture: true,
    async listDevices() { return [{ name: 'Escolher ao conectar…', address: 'WEBBT' }]; },
    create() { return new WebBtTransport(); },
  };
})();
