/* Gerenciador da fonte OBD2: escolhe o transporte, conecta, inicializa o ELM327,
 * mantém a sessão e se reconecta sozinho com recuo progressivo.
 * A interface não conhece nada disso — ela só lê CC.data e CC.link. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const BACKOFF = [2000, 4000, 8000, 15000];

  const O = {
    elm: null, transport: null, gen: 0, retries: 0, logBuf: [], timer: null,

    logLine(s) { O.logBuf.push(s); if (O.logBuf.length > 80) O.logBuf.shift(); CC.bus.emit('obdlog'); },
    logLines() { return O.logBuf; },

    transports() { return CC.transports || {}; },
    pick() {
      const T = O.transports(), want = CC.settings.transport;
      if (want !== 'auto') return T[want] && T[want].available() ? T[want] : null;
      if (T.bridge && T.bridge.available()) return T.bridge;
      if (T.webbt && T.webbt.available()) return T.webbt;
      return null;
    },

    async start(interactive) {
      O.halt();
      const gen = ++O.gen;
      CC.link.setMode('obd');
      CC.data.clear();
      const tr = O.pick();
      if (!tr) {
        CC.link.set('error', 'Nenhum adaptador Bluetooth utilizável neste aparelho. Use o app Android ou o modo "ELM327 emulado".');
        return;
      }
      CC.link.set('connecting', 'Conectando via ' + tr.label + '…', { transport: tr.label });
      O.logLine('--- nova sessão: ' + tr.label + ' ---');
      let t = null, everReady = false;
      try {
        t = tr.create(); O.transport = t;
        let dev = CC.settings.device;
        if (tr.id === 'bridge' && !dev.address) throw new Error('Escolha o adaptador em Configurações › OBD2.');
        if (tr.id === 'emulator') dev = { name: 'ELM327 virtual', address: 'EMU' };
        t.onClose = (why) => { if (gen === O.gen) O.logLine('! transporte fechou: ' + why); };
        await t.connect(dev, interactive);
        if (gen !== O.gen) { t.close(); return; }

        const elm = new CC.Elm327(t, {
          protocol: CC.settings.protocol, rate: CC.settings.pollRate,
          onValue: (k, v, q) => CC.data.set(k, v, q),
          onNA: (k, why) => CC.data.setNA(k, why),
          onState: (s, i) => { if (gen === O.gen) CC.link.set(s, i); },
          onLog: (l) => O.logLine(l),
        });
        O.elm = elm;

        while (gen === O.gen) {
          try {
            await elm.init();
            if (gen !== O.gen) return;
            everReady = true; O.retries = 0;
            CC.link.set('ready', 'Conectado · ' + (elm.version || 'ELM327'), { version: elm.version, protocol: elm.protocolName });
            await elm.run();
            if (gen !== O.gen) return;
            if (elm.lost) throw elm.lost;
            return; // parado manualmente
          } catch (e) {
            if (gen !== O.gen) return;
            Object.keys(CC.PARAMS).forEach((k) => CC.data.setNA(k, 'sem comunicação'));
            CC.link.set(everReady ? 'lost' : 'error', e.message || String(e));
            O.logLine('! ' + (e.message || e));
            if (!t.alive) break; // enlace Bluetooth caiu → reconecta do zero
            const wait = BACKOFF[Math.min(O.retries++, BACKOFF.length - 1)];
            await sleep(wait);
            elm.fail = 0; elm.lost = null; elm.chain = Promise.resolve(); elm.running = false;
          }
        }
        throw new Error(CC.link.get().info || 'conexão perdida');
      } catch (e) {
        if (gen !== O.gen) return;
        Object.keys(CC.PARAMS).forEach((k) => CC.data.setNA(k, 'sem comunicação'));
        CC.link.set(everReady ? 'lost' : 'error', e.message || String(e));
        O.logLine('! ' + (e.message || e));
        try { t && t.close(); } catch (x) { /* ignora */ }
        if (tr.needsGesture) return; // Web Bluetooth: só reconecta com toque
        const wait = BACKOFF[Math.min(O.retries++, BACKOFF.length - 1)];
        O.timer = setTimeout(() => { if (gen === O.gen) O.start(false); }, wait);
      }
    },

    /** encerra sessão (sem mudar o modo) */
    halt() {
      O.gen++;
      clearTimeout(O.timer); O.timer = null;
      if (O.elm) { try { O.elm.stop(); } catch (e) { /* ignora */ } O.elm = null; }
      if (O.transport) { try { O.transport.close(); } catch (e) { /* ignora */ } O.transport = null; }
    },
    stop() { O.halt(); CC.link.set('idle', 'Desconectado'); },

    /** tabela de suporte de PIDs para a tela Motor */
    pidTable() {
      return Object.keys(CC.PARAMS).map((k) => {
        const p = CC.PARAMS[k];
        const e = CC.data.get(k);
        const info = O.elm && O.elm.pidInfo && O.elm.pidInfo[k];
        return { key: k, pid: p.pid, label: p.label, q: e ? e.q : 'na', note: (info && info.note) || (e && e.q === 'na' ? e.why : ''), supported: info ? info.supported : null };
      });
    },
    ready() { return !!(O.elm && CC.link.get().state === 'ready' && CC.link.get().mode === 'obd'); },
    async readDtc() { if (!O.ready()) throw new Error('OBD2 não conectado'); return O.elm.readDtc(); },
    async readMil() { if (!O.ready()) throw new Error('OBD2 não conectado'); return O.elm.readMil(); },
  };
  CC.obd = O;
})();
