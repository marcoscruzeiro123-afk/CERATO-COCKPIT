/* Transporte "ELM327 emulado": um adaptador + ECU virtuais dentro do navegador.
 * Serve para testar TODA a pilha OBD2 (init, detecção de PIDs suportados, consulta, parsing,
 * perda de comunicação) sem carro e sem adaptador.
 *
 * A ECU virtual propositalmente NÃO suporta: PID 10 (MAF), 2F (nível de combustível) e 42 (tensão),
 * para exercitar os caminhos "indisponível", estimativa por MAP e tensão via ATRV. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  CC.transports = CC.transports || {};
  const hex2 = (n) => (Math.max(0, Math.min(255, Math.round(n))) < 16 ? '0' : '') + Math.max(0, Math.min(255, Math.round(n))).toString(16).toUpperCase();

  const SUPPORTED = ['01', '03', '04', '05', '06', '0B', '0C', '0D', '0E', '0F', '11', '20']; // faixa 00
  const SUPPORTED_20 = ['21']; // faixa 20 (sem 2F nem 40)

  function mask(pids, base) {
    let v = 0;
    pids.forEach((p) => { const n = parseInt(p, 16) - base - 1; if (n >= 0 && n < 32) v |= 1 << (31 - n); });
    v >>>= 0;
    return [24, 16, 8, 0].map((s) => hex2((v >>> s) & 255)).join('');
  }

  class EmuTransport {
    constructor() {
      this.onData = null; this.onClose = null;
      this.echo = true; this.spaces = true; this.dead = 0; this.t0 = Date.now(); this.alive = false; this.first = true;
    }
    async connect() { await new Promise((r) => setTimeout(r, 350)); this.alive = true; this.t0 = Date.now(); }
    close() { this.alive = false; }
    /** simula queda de comunicação por N segundos */
    dropout(sec) { this.dead = Date.now() + sec * 1000; }

    _state() {
      const t = (Date.now() - this.t0) / 1000, c = t % 90;
      const sp = c < 8 ? 0 : c < 25 ? (c - 8) * 3.2 : c < 55 ? 54 + 20 * Math.sin(c / 5) : c < 75 ? 74 - (c - 55) * 3.2 : 0;
      const gear = sp < 20 ? 1 : sp < 35 ? 2 : sp < 50 ? 3 : sp < 68 ? 4 : sp < 85 ? 5 : 6;
      const k = [4.162, 2.372, 1.552, 1.158, 0.851, 0.672][gear - 1] * 3.51 * 1000 / (60 * 1.99);
      return { speed: sp, rpm: sp < 3 ? 800 : Math.max(820, sp * k), coolant: Math.min(88, 55 + t * 0.4), iat: 34 + 3 * Math.sin(t / 30), load: 20 + sp * 0.5, thr: sp * 0.4, map: 32 + sp * 0.6, timing: 14 + 3 * Math.sin(t / 3), stft: 1.5 * Math.sin(t) };
    }

    _answer(cmd) {
      const c = cmd.replace(/\s+/g, '').toUpperCase();
      if (c === 'ATZ') { this.echo = true; this.spaces = true; this.first = true; return 'ELM327 v1.5'; }
      if (c === 'ATE0') { this.echo = false; return 'OK'; }
      if (c === 'ATS0') { this.spaces = false; return 'OK'; }
      if (c === 'ATDPN') return 'A6';
      if (c === 'ATRV') return (13.9 + 0.2 * Math.sin(Date.now() / 4000)).toFixed(1) + 'V';
      if (/^AT/.test(c)) return 'OK';
      const j = (a) => (this.spaces ? a.match(/.{1,2}/g).join(' ') : a);
      if (c === '0100') { const r = (this.first ? 'SEARCHING...\r' : ''); this.first = false; return r + j('4100' + mask(SUPPORTED, 0)); }
      if (c === '0120') return j('4120' + mask(SUPPORTED_20, 0x20));
      if (c === '0101') return j('410181070000');
      if (c === '03') return j('430133' + '0420' + '0000');
      if (c === '04') return 'NO DATA';
      const m = /^01([0-9A-F]{2})$/.exec(c);
      if (!m) return '?';
      const s = this._state(), pid = m[1];
      const all = new Set(SUPPORTED.concat(SUPPORTED_20));
      if (!all.has(pid) || pid === '20' || pid === '21') return 'NO DATA';
      let d;
      switch (pid) {
        case '04': d = hex2(s.load * 255 / 100); break;
        case '05': d = hex2(s.coolant + 40); break;
        case '06': d = hex2(128 + s.stft * 128 / 100); break;
        case '0B': d = hex2(s.map); break;
        case '0C': d = ('0000' + Math.round(s.rpm * 4).toString(16).toUpperCase()).slice(-4); break;
        case '0D': d = hex2(s.speed); break;
        case '0E': d = hex2((s.timing + 64) * 2); break;
        case '0F': d = hex2(s.iat + 40); break;
        case '11': d = hex2(s.thr * 255 / 100); break;
        default: return 'NO DATA';
      }
      return j('41' + pid + d);
    }

    write(str) {
      str.split('\r').filter((x) => x.trim()).forEach((cmd) => {
        if (Date.now() < this.dead) return; // adaptador "mudo"
        const delay = 25 + Math.random() * 50;
        setTimeout(() => {
          if (!this.alive || Date.now() < this.dead) return;
          const body = this._answer(cmd);
          const out = (this.echo ? cmd + '\r' : '') + body + '\r\r>';
          // entrega em dois pedaços para exercitar o remontador de linhas
          const cut = Math.floor(out.length / 2);
          if (this.onData) this.onData(out.slice(0, cut));
          setTimeout(() => { if (this.onData) this.onData(out.slice(cut)); }, 5);
        }, delay);
      });
    }
  }

  CC.transports.emulator = {
    id: 'emulator',
    label: 'ELM327 emulado (teste)',
    available: () => true,
    async listDevices() { return [{ name: 'ELM327 virtual', address: 'EMU' }]; },
    create() { const t = new EmuTransport(); CC.emulator = t; return t; },
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = CC;
})();
