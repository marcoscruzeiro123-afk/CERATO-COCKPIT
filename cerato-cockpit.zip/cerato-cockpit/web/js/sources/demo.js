/* Fonte de dados DEMONSTRAÇÃO: simula um ciclo de condução completo.
 * Tudo que sai daqui é gravado com qualidade "sim" — a interface sempre mostra que é simulado.
 * Interface da fonte: start(), stop(). Mesma que a fonte OBD2 real implementa (ver obd.js). */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const { clamp } = CC.util;

  // perfil de velocidade alvo (km/h) ao longo de um ciclo de 150 s
  const PROFILE = [[0, 0], [6, 0], [18, 55], [35, 55], [45, 25], [55, 90], [85, 108], [100, 124], [110, 124], [130, 40], [142, 0], [150, 0]];
  const CYCLE = 150;
  function target(t) {
    t = t % CYCLE;
    for (let i = 1; i < PROFILE.length; i++) {
      if (t <= PROFILE[i][0]) {
        const [t0, v0] = PROFILE[i - 1], [t1, v1] = PROFILE[i];
        const f = (t - t0) / (t1 - t0 || 1);
        return v0 + (v1 - v0) * f * f * (3 - 2 * f); // suavizado
      }
    }
    return 0;
  }
  const UP = [20, 35, 50, 68, 85], DOWN = [13, 27, 41, 57, 73];

  const S = {
    scenario: 'normal', timer: null, t: 0, last: 0,
    speed: 0, prevSpeed: 0, gear: 1, shiftT: 0, rpm: 800, coolant: 58, fuel: 68,
    volt: 14.1, iat: 33, throttle: 0, load: 18, hotBias: 0,
  };

  function step() {
    const now = CC.util.now();
    const dt = Math.min(0.5, (now - S.last) / 1000); S.last = now; S.t += dt;
    const sc = S.scenario;

    if (sc === 'lost') return; // sem dados: valores já marcados como indisponíveis

    /* velocidade */
    const tg = sc === 'idle' ? 0 : target(S.t);
    const maxD = 7 * dt;
    S.prevSpeed = S.speed;
    S.speed = clamp(S.speed + clamp(tg - S.speed, -maxD * 1.3, maxD), 0, 240);
    const acc = (S.speed - S.prevSpeed) / dt; // km/h por s

    /* marcha automática */
    let g = S.gear;
    if (g < 6 && S.speed > UP[g - 1]) { g++; S.shiftT = 0.55; }
    else if (g > 1 && S.speed < DOWN[g - 2]) { g--; S.shiftT = 0.4; }
    S.gear = g;
    if (S.shiftT > 0) S.shiftT -= dt;

    /* rotação */
    const k = CC.gearK()[g - 1];
    let rpm = S.speed < 4 ? 790 + 22 * Math.sin(S.t * 5.1) : Math.max(820, k * S.speed);
    if (acc > 2 && g === 1) rpm = Math.max(rpm, 1400 + acc * 90);       // "flare" do conversor
    if (S.shiftT > 0) rpm *= 0.9 + 0.1 * (1 - S.shiftT);
    rpm += acc > 1 ? acc * 38 : 0;
    S.rpm += (rpm - S.rpm) * Math.min(1, dt * 9);
    S.rpm = clamp(S.rpm, 700, 6900);

    /* acelerador e carga */
    S.throttle = clamp(acc > 0.3 ? 14 + acc * 5.5 + S.speed * 0.08 : S.speed > 5 ? 8 + S.speed * 0.09 : 0, 0, 100);
    S.load = clamp(16 + S.throttle * 0.65 + (S.speed / 240) * 20 + (acc > 0 ? acc * 2 : 0), 12, 98);

    /* temperatura do motor */
    const warm = 88 + 1.6 * Math.sin(S.t / 23) + (S.speed > 100 ? 1.2 : 0);
    if (sc === 'hot') S.hotBias = Math.min(26, S.hotBias + dt * 0.45); else S.hotBias = Math.max(0, S.hotBias - dt * 0.8);
    const goal = warm + S.hotBias;
    const rate = S.coolant < warm - 3 ? 0.35 : 0.08;
    S.coolant += clamp(goal - S.coolant, -1.2 * dt, rate * dt * (S.hotBias > 0 ? 6 : 1));

    /* elétrica */
    let vg = S.rpm > 600 ? 14.1 + 0.18 * Math.sin(S.t / 3.3) - (S.load > 70 ? 0.15 : 0) : 12.5;
    if (sc === 'lowvolt') vg = 11.3 + 0.1 * Math.sin(S.t);
    S.volt += (vg - S.volt) * Math.min(1, dt * 2);

    /* admissão e combustível */
    S.iat += ((30 + 7 * (1 - Math.min(1, S.speed / 70)) + S.load * 0.04) - S.iat) * dt * 0.05;
    const map = clamp(28 + S.load * 0.72, 25, 98);
    const maf = ((S.rpm / 120) * 0.001591 * map * 1000 / (287 * (S.iat + 273.15))) * 0.8 * 1000;
    S.fuel = Math.max(0, S.fuel - (maf / 13.2 * 3600 / 750) / 3600 / 50 * 100 * dt); // vazão real → % do tanque de 50 L
    const slosh = 0.4 * Math.sin(S.t / 4);

    const Q = 'sim', D = CC.data;
    D.set('speed', S.speed, Q);
    D.set('rpm', S.rpm, Q);
    D.set('coolant', S.coolant, Q);
    D.set('iat', S.iat, Q);
    D.set('voltage', S.volt, Q);
    D.set('load', S.load, Q);
    D.set('throttle', S.throttle, Q);
    D.set('fuel', clamp(S.fuel + slosh, 0, 100), Q);
    D.set('map', map, Q);
    D.set('maf', maf, Q);
    D.set('timing', 12 + S.load * 0.12 + 4 * Math.sin(S.t * 2), Q);
    D.set('stft', 1.5 * Math.sin(S.t * 1.3), Q);
    D.set('ltft', 2.2 + 0.4 * Math.sin(S.t / 9), Q);
    D.set('ambient', 29, Q);
  }

  CC.demo = {
    scenarios: [
      { id: 'normal', label: 'Normal' },
      { id: 'idle', label: 'Parado' },
      { id: 'hot', label: 'Superaquecimento' },
      { id: 'lowvolt', label: 'Bateria baixa' },
      { id: 'lost', label: 'Falha OBD2' },
    ],
    scenario: () => S.scenario,
    setScenario(id) {
      const was = S.scenario;
      S.scenario = id;
      if (id === 'lost') {
        Object.keys(CC.PARAMS).forEach((k) => CC.data.setNA(k, 'sem comunicação'));
        CC.link.set('lost', 'Falha simulada');
      } else if (was === 'lost') {
        CC.link.set('ready', 'Simulação');
      }
      if (id === 'hot') { S.coolant = Math.max(S.coolant, 88); }
      CC.bus.emit('demo', id);
    },
    start() {
      if (S.timer) return;
      S.last = CC.util.now();
      CC.link.setMode('demo');
      CC.link.set('ready', 'Dados simulados');
      step();
      S.timer = setInterval(step, 100);
    },
    stop() { clearInterval(S.timer); S.timer = null; },
  };
})();
