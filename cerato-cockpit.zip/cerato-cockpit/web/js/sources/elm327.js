/* Driver ELM327 (independente do meio de transporte).
 *
 * O driver só precisa de um "transporte" com:
 *   transport.onData  = (texto) => {}   // chamado pelo transporte ao receber bytes
 *   transport.onClose = (motivo) => {}  // chamado se a conexão cair
 *   transport.write(texto)              // envia (já com \r no fim)
 *   transport.close()
 *
 * Princípios:
 *  - Nunca inventa valores: um PID só é consultado se a ECU declarou suporte (0100/0120/0140…).
 *  - PID suportado que deixa de responder é marcado como indisponível ("sem resposta").
 *  - Tensão: usa PID 42 se existir; senão usa ATRV (tensão medida pelo adaptador no conector OBD2).
 */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const hex2 = (n) => (n < 16 ? '0' : '') + n.toString(16).toUpperCase();

  /* ---------- decodificadores (SAE J1979, modo 01) ---------- */
  const PID_TABLE = {
    '04': { bytes: 1, f: (b) => (b[0] * 100) / 255 },
    '05': { bytes: 1, f: (b) => b[0] - 40 },
    '06': { bytes: 1, f: (b) => ((b[0] - 128) * 100) / 128 },
    '07': { bytes: 1, f: (b) => ((b[0] - 128) * 100) / 128 },
    '0B': { bytes: 1, f: (b) => b[0] },
    '0C': { bytes: 2, f: (b) => (b[0] * 256 + b[1]) / 4 },
    '0D': { bytes: 1, f: (b) => b[0] },
    '0E': { bytes: 1, f: (b) => b[0] / 2 - 64 },
    '0F': { bytes: 1, f: (b) => b[0] - 40 },
    '10': { bytes: 2, f: (b) => (b[0] * 256 + b[1]) / 100 },
    '11': { bytes: 1, f: (b) => (b[0] * 100) / 255 },
    '2F': { bytes: 1, f: (b) => (b[0] * 100) / 255 },
    '42': { bytes: 2, f: (b) => (b[0] * 256 + b[1]) / 1000 },
    '46': { bytes: 1, f: (b) => b[0] - 40 },
  };

  /* ordem/frequência de consulta: "every" = a cada N ciclos */
  const PLAN = [
    { key: 'rpm', pid: '0C', every: 1 },
    { key: 'speed', pid: '0D', every: 1 },
    { key: 'throttle', pid: '11', every: 2 },
    { key: 'load', pid: '04', every: 2 },
    { key: 'map', pid: '0B', every: 3 },
    { key: 'maf', pid: '10', every: 2 },
    { key: 'coolant', pid: '05', every: 6 },
    { key: 'iat', pid: '0F', every: 6 },
    { key: 'voltage', pid: '42', every: 8 },
    { key: 'timing', pid: '0E', every: 5 },
    { key: 'stft', pid: '06', every: 6 },
    { key: 'ltft', pid: '07', every: 12 },
    { key: 'fuel', pid: '2F', every: 30 },
    { key: 'ambient', pid: '46', every: 60 },
  ];

  const ERR_RE = /(UNABLE TO CONNECT|NO DATA|CAN ERROR|BUS BUSY|BUS ERROR|BUFFER FULL|DATA ERROR|FB ERROR|LV RESET|STOPPED|ERROR|^\?$)/i;

  /* ---------- funções puras (testáveis) ---------- */
  function cleanHex(line) { return line.replace(/[^0-9A-Fa-f]/g, '').toUpperCase(); }
  function toBytes(h) { const o = []; for (let i = 0; i + 1 < h.length; i += 2) o.push(parseInt(h.substr(i, 2), 16)); return o; }

  /** Extrai os bytes de dados de uma resposta do modo 01 para o PID dado, ou null. */
  function parsePid(lines, pid) {
    const need = (PID_TABLE[pid] && PID_TABLE[pid].bytes) || 0;
    for (const ln of lines) {
      if (ERR_RE.test(ln) && !/^[0-9A-F ]+$/i.test(ln)) continue;
      const h = cleanHex(ln), tag = '41' + pid;
      const i = h.indexOf(tag);
      if (i === 0 || i === 3) { // i === 3: adaptador com cabeçalho de 3 dígitos ligado
        const b = toBytes(h.slice(i + 4));
        if (b.length >= need && need > 0) return b.slice(0, need);
      }
    }
    return null;
  }

  /** Une máscaras de PIDs suportados (4 bytes) de uma ou mais ECUs. base = 0x00, 0x20, 0x40… */
  function parseSupported(lines, rangePid) {
    const set = new Set();
    for (const ln of lines) {
      const h = cleanHex(ln), tag = '41' + rangePid;
      let i = h.indexOf(tag);
      if (i !== 0 && i !== 3) continue;
      const b = toBytes(h.slice(i + 4));
      if (b.length < 4) continue;
      const base = parseInt(rangePid, 16);
      const v = ((b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]) >>> 0;
      for (let n = 0; n < 32; n++) if ((v >>> (31 - n)) & 1) set.add(hex2(base + n + 1));
    }
    return set;
  }

  /** Decodifica códigos de falha (modo 03). isCan: primeira byte após 43 é a contagem. */
  function parseDtc(lines, isCan) {
    const out = [];
    for (const ln of lines) {
      const h = cleanHex(ln);
      const i = h.indexOf('43');
      if (i !== 0 && i !== 3) continue;
      let b = toBytes(h.slice(i + 2));
      if (isCan && b.length % 2 === 1) b = b.slice(1);
      for (let k = 0; k + 1 < b.length; k += 2) {
        const a = b[k], c = b[k + 1];
        if (a === 0 && c === 0) continue;
        const letter = 'PCBU'[(a >> 6) & 3];
        const code = letter + ((a >> 4) & 3) + (a & 15).toString(16).toUpperCase() + hex2(c);
        if (!out.includes(code)) out.push(code);
      }
    }
    return out;
  }

  const isNoData = (lines) => lines.length === 0 || lines.some((l) => /NO DATA|UNABLE TO CONNECT|CAN ERROR|BUS ERROR|BUS BUSY|STOPPED|FB ERROR|DATA ERROR/i.test(l));

  /* ---------- driver ---------- */
  class Elm327 {
    constructor(transport, opts) {
      this.t = transport;
      this.o = Object.assign({ protocol: '0', rate: 'normal', onValue() {}, onNA() {}, onState() {}, onLog() {} }, opts || {});
      this.buf = '';
      this.pending = null;
      this.chain = Promise.resolve();
      this.running = false;
      this.supported = new Set();
      this.pidInfo = {};      // key -> {pid, supported, ok, miss, nextTry, note}
      this.voltageViaAdapter = false;
      this.version = ''; this.protocolName = ''; this.isCan = false;
      this.fail = 0;
      transport.onData = (s) => this._onData(s);
      const prevClose = transport.onClose;
      transport.onClose = (why) => { this._closed(why); if (prevClose) prevClose(why); };
    }

    log(s) { this.o.onLog(s); }

    /* ----- E/S de linha ----- */
    _onData(chunk) {
      this.buf += chunk;
      const idx = this.buf.indexOf('>');
      if (idx >= 0 && this.pending) {
        const raw = this.buf.slice(0, idx);
        this.buf = this.buf.slice(idx + 1);
        const p = this.pending; this.pending = null; clearTimeout(p.timer);
        let lines = raw.split(/[\r\n]+/).map((l) => l.trim()).filter(Boolean);
        lines = lines.filter((l) => l.toUpperCase() !== p.cmd.toUpperCase() && !/^SEARCHING/i.test(l) && !/^BUS INIT/i.test(l));
        this.log('< ' + (lines.join(' | ') || '(vazio)'));
        p.resolve(lines);
      } else if (idx >= 0) {
        this.buf = this.buf.slice(idx + 1); // prompt solto
      }
    }
    _closed(why) {
      if (this.pending) { const p = this.pending; this.pending = null; clearTimeout(p.timer); p.reject(new Error('conexão encerrada')); }
      this.running = false;
      this.closedWhy = why || 'conexão encerrada';
    }
    send(cmd, timeout) {
      const run = () => new Promise((resolve, reject) => {
        if (this.closedWhy && !this.t.alive) { /* deixa o transporte decidir */ }
        this.buf = '';
        this.pending = { cmd, resolve, reject, timer: setTimeout(() => {
          this.pending = null;
          this.log('! timeout em ' + cmd);
          reject(new Error('timeout ' + cmd));
        }, timeout || 2500) };
        this.log('> ' + cmd);
        try { this.t.write(cmd + '\r'); } catch (e) { clearTimeout(this.pending.timer); this.pending = null; reject(e); }
      });
      const p = this.chain.then(run, run);
      this.chain = p.catch(() => {});
      return p;
    }

    /* ----- inicialização ----- */
    async init() {
      this.o.onState('connecting', 'Inicializando ELM327…');
      let r = await this.send('ATZ', 6000);
      this.version = (r.find((l) => /ELM|OBD|v\d/i.test(l)) || r.join(' ') || '').trim();
      for (const c of ['ATE0', 'ATL0', 'ATS0', 'ATH0', 'ATAT1', 'ATST64']) await this.send(c, 2500);
      await this.send('ATSP' + this.o.protocol, 2500);

      this.o.onState('connecting', 'Procurando a ECU (protocolo ' + (this.o.protocol === '0' ? 'automático' : this.o.protocol) + ')…');
      let lines = await this.send('0100', 25000);
      if (isNoData(lines) || !parseSupported(lines, '00').size) {
        await sleep(600);
        lines = await this.send('0100', 25000); // KWP/ISO às vezes precisa de uma segunda tentativa
      }
      let sup = parseSupported(lines, '00');
      if (!sup.size) throw new Error('A ECU não respondeu. Confirme ignição ligada e o protocolo.');

      this.supported = new Set(sup);
      for (const base of ['20', '40', '60']) {
        if (!sup.has(base)) break;
        const l = await this.send('01' + base, 4000);
        const s2 = parseSupported(l, base);
        s2.forEach((p) => this.supported.add(p));
        sup = s2;
        if (!s2.size) break;
      }
      try {
        const dpn = (await this.send('ATDPN', 2000))[0] || '';
        this.protocolName = dpn.replace(/^A/i, '');
        this.isCan = /^[6-9A-C]$/i.test(this.protocolName);
      } catch (e) { /* opcional */ }

      /* matriz de suporte */
      this.pidInfo = {};
      for (const p of PLAN) {
        const ok = this.supported.has(p.pid);
        this.pidInfo[p.key] = { pid: p.pid, supported: ok, ok: false, miss: 0, nextTry: 0, note: ok ? '' : 'não suportado pela ECU' };
        if (!ok) this.o.onNA(p.key, 'não suportado pela ECU');
      }
      if (!this.pidInfo.voltage.supported) {
        this.voltageViaAdapter = true;
        this.pidInfo.voltage.note = 'via adaptador (ATRV)';
      }
      this.log('PIDs suportados: ' + [...this.supported].sort().join(' '));
      this.fail = 0;
      this.o.onState('ready', 'Conectado · ' + (this.version || 'ELM327'));
    }

    /* ----- laço de consulta ----- */
    async run() {
      this.running = true;
      let n = 0, lastRv = 0;
      const mult = { lento: 2, normal: 1, rapido: 0.5 }[this.o.rate] || 1;
      while (this.running) {
        n++;
        const now = Date.now();
        for (const p of PLAN) {
          if (!this.running) return;
          const info = this.pidInfo[p.key];
          if (!info || !info.supported) continue;
          if (n % Math.max(1, Math.round(p.every * mult)) !== 0 && info.ok) continue;
          if (info.nextTry > now) continue;
          await this._query(p, info);
        }
        if (this.voltageViaAdapter && now - lastRv > 4000) {
          lastRv = now;
          try {
            const l = await this.send('ATRV', 2000);
            const v = parseFloat((l[0] || '').replace(',', '.'));
            if (isFinite(v) && v > 3 && v < 40) { this.o.onValue('voltage', v, 'real'); this.pidInfo.voltage.ok = true; this.fail = 0; }
          } catch (e) { this._bump(e); }
        }
        await sleep(0);
      }
    }

    async _query(p, info) {
      let lines;
      try { lines = await this.send('01' + p.pid, 3500); }
      catch (e) { this._bump(e); return; }
      const b = parsePid(lines, p.pid);
      if (b) {
        const dec = PID_TABLE[p.pid];
        this.o.onValue(p.key, dec.f(b), 'real');
        info.ok = true; info.miss = 0; this.fail = 0; info.note = '';
        return;
      }
      if (lines.some((l) => /UNABLE TO CONNECT|CAN ERROR|BUS ERROR|BUS BUSY|STOPPED|BUFFER FULL|LV RESET/i.test(l))) { this._bump(new Error(lines.join(' '))); return; }
      info.miss++;
      if (info.miss >= 6) {
        info.ok = false; info.nextTry = Date.now() + 60000; info.note = 'sem resposta';
        this.o.onNA(p.key, 'sem resposta da ECU');
      }
    }

    _bump(e) {
      this.fail++;
      if (this.fail >= 4) { this.running = false; this.lost = e; }
    }

    /* ----- ferramentas extras ----- */
    async readMil() {
      const l = await this.send('0101', 4000);
      const h = cleanHex(l.find((x) => cleanHex(x).indexOf('4101') >= 0) || '');
      const i = h.indexOf('4101');
      if (i < 0) return null;
      const a = parseInt(h.substr(i + 4, 2), 16);
      return { mil: !!(a & 0x80), count: a & 0x7f };
    }
    async readDtc() {
      const l = await this.send('03', 8000);
      if (l.some((x) => /NO DATA/i.test(x))) return [];
      return parseDtc(l, this.isCan);
    }

    stop() { this.running = false; }
  }

  CC.Elm327 = Elm327;
  CC.elmUtil = { parsePid, parseSupported, parseDtc, PID_TABLE, PLAN, isNoData, sleep };
  if (typeof module !== 'undefined' && module.exports) module.exports = CC;
})();
