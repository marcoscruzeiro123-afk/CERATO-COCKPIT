/* Transporte "ponte Android": usa o aplicativo nativo (WebView) que expõe `AndroidOBD`.
 * É o caminho recomendado para adaptadores ELM327 Bluetooth CLÁSSICOS (SPP/RFCOMM),
 * que o Web Bluetooth não consegue acessar.
 *
 * Contrato nativo (ver android/.../BtBridge.kt):
 *   AndroidOBD.listPairedDevices() -> JSON '[{"name":"OBDII","address":"00:1D:..."}]'
 *   AndroidOBD.connect(address)    -> assíncrono; resultado via CCNative.onState
 *   AndroidOBD.write(texto)        -> envia bytes ao adaptador
 *   AndroidOBD.disconnect()
 * Callbacks JS chamados pelo nativo:
 *   CCNative.onState('connected' | 'error' | 'closed', mensagem)
 *   CCNative.onData(texto)
 */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  CC.transports = CC.transports || {};

  class BridgeTransport {
    constructor() { this.onData = null; this.onClose = null; this.alive = false; }
    connect(dev) {
      return new Promise((resolve, reject) => {
        let settled = false;
        globalThis.CCNative = {
          onData: (s) => { if (this.onData) this.onData(s); },
          onState: (st, msg) => {
            if (st === 'connected') { this.alive = true; if (!settled) { settled = true; resolve(); } }
            else if (st === 'error') { this.alive = false; if (!settled) { settled = true; reject(new Error(msg || 'falha ao conectar')); } else if (this.onClose) this.onClose(msg); }
            else if (st === 'closed') { this.alive = false; if (this.onClose) this.onClose(msg || 'conexão encerrada'); }
          },
        };
        setTimeout(() => { if (!settled) { settled = true; reject(new Error('tempo esgotado ao conectar ao adaptador')); } }, 20000);
        try { globalThis.AndroidOBD.connect(dev.address); } catch (e) { settled = true; reject(e); }
      });
    }
    write(s) { globalThis.AndroidOBD.write(s); }
    close() { this.alive = false; try { globalThis.AndroidOBD.disconnect(); } catch (e) { /* ignora */ } }
  }

  CC.transports.bridge = {
    id: 'bridge',
    label: 'Android nativo (Bluetooth clássico)',
    available: () => typeof globalThis.AndroidOBD !== 'undefined',
    async listDevices() {
      try { return JSON.parse(globalThis.AndroidOBD.listPairedDevices() || '[]'); } catch (e) { return []; }
    },
    create() { return new BridgeTransport(); },
  };
})();
