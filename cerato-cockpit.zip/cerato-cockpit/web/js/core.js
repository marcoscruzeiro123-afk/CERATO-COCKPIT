/* Cerato Digital Cockpit — núcleo: barramento de eventos, catálogo de parâmetros e armazenamento de dados.
 *
 * Toda fonte de dados (demonstração, OBD2 real, emulador) grava no mesmo CC.data.
 * Cada valor carrega uma QUALIDADE, para a interface nunca confundir real com simulado:
 *   real  – lido da ECU / adaptador
 *   calc  – calculado a partir de dados reais
 *   est   – estimado com premissas (ex.: eficiência volumétrica)
 *   sim   – simulado (modo demonstração)
 *   na    – indisponível (ECU não suporta / sem resposta)
 */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});

  /* ---------- barramento ---------- */
  const handlers = {};
  CC.bus = {
    on(ev, fn) { (handlers[ev] = handlers[ev] || []).push(fn); return () => CC.bus.off(ev, fn); },
    off(ev, fn) { handlers[ev] = (handlers[ev] || []).filter((f) => f !== fn); },
    emit(ev, a, b) {
      (handlers[ev] || []).slice().forEach((fn) => { try { fn(a, b); } catch (e) { console.error('[bus]', ev, e); } });
    },
  };

  /* ---------- utilidades ---------- */
  CC.util = {
    clamp: (v, a, b) => Math.min(b, Math.max(a, v)),
    lerp: (a, b, t) => a + (b - a) * t,
    now: () => (typeof performance !== 'undefined' ? performance.now() : Date.now()),
    pad2: (n) => (n < 10 ? '0' : '') + n,
    fmt(v, d) { return v == null || !isFinite(v) ? '--' : Number(v).toFixed(d == null ? 0 : d); },
    el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; },
  };

  /* ---------- catálogo de parâmetros ---------- */
  // pid = código hexadecimal do modo 01
  CC.PARAMS = {
    speed:    { label: 'Velocidade',          unit: 'km/h', pid: '0D', dec: 0 },
    rpm:      { label: 'Rotação',             unit: 'rpm',  pid: '0C', dec: 0 },
    coolant:  { label: 'Temp. do motor',      unit: '°C',   pid: '05', dec: 0 },
    iat:      { label: 'Ar de admissão',      unit: '°C',   pid: '0F', dec: 0 },
    voltage:  { label: 'Tensão da bateria',   unit: 'V',    pid: '42', dec: 1 },
    load:     { label: 'Carga do motor',      unit: '%',    pid: '04', dec: 0 },
    fuel:     { label: 'Nível de combustível', unit: '%',   pid: '2F', dec: 0 },
    throttle: { label: 'Posição do acelerador', unit: '%',  pid: '11', dec: 0 },
    map:      { label: 'Pressão do coletor',  unit: 'kPa',  pid: '0B', dec: 0 },
    maf:      { label: 'Fluxo de ar (MAF)',   unit: 'g/s',  pid: '10', dec: 1 },
    timing:   { label: 'Avanço de ignição',   unit: '°',    pid: '0E', dec: 1 },
    stft:     { label: 'Correção curta (STFT)', unit: '%',  pid: '06', dec: 1 },
    ltft:     { label: 'Correção longa (LTFT)', unit: '%',  pid: '07', dec: 1 },
    ambient:  { label: 'Temp. ambiente',      unit: '°C',   pid: '46', dec: 0 },
  };

  /* ---------- armazenamento ---------- */
  const store = {};
  const STALE_MS = 5000;
  CC.data = {
    set(key, v, q) { store[key] = { v, q: q || 'real', t: CC.util.now(), why: '' }; },
    setNA(key, why) { store[key] = { v: null, q: 'na', t: CC.util.now(), why: why || 'indisponível' }; },
    get(key) { return store[key] || null; },
    /** valor numérico fresco, ou null. */
    val(key) {
      const e = store[key];
      if (!e || e.q === 'na' || e.v == null) return null;
      if (e.q !== 'sim' && CC.util.now() - e.t > STALE_MS) return null;
      return e.v;
    },
    quality(key) { const e = store[key]; return e ? e.q : 'na'; },
    age(key) { const e = store[key]; return e ? CC.util.now() - e.t : Infinity; },
    why(key) { const e = store[key]; return e ? e.why : ''; },
    keys() { return Object.keys(store); },
    clear() { for (const k of Object.keys(store)) delete store[k]; },
  };
  CC.data.STALE_MS = STALE_MS;

  /* ---------- estado do enlace com a fonte de dados ----------
   * state: idle | connecting | ready | lost | error
   * mode : demo | obd
   */
  const link = { mode: 'demo', state: 'idle', info: '', since: CC.util.now(), transport: '', version: '', protocol: '' };
  CC.link = {
    get() { return link; },
    set(state, info, extra) {
      const changed = link.state !== state || link.info !== (info || '');
      if (link.state !== state) link.since = CC.util.now();
      link.state = state; link.info = info || '';
      if (extra) Object.assign(link, extra);
      if (changed) CC.bus.emit('link', link);
    },
    setMode(mode) { link.mode = mode; CC.bus.emit('link', link); },
    secondsInState() { return (CC.util.now() - link.since) / 1000; },
  };
})();
