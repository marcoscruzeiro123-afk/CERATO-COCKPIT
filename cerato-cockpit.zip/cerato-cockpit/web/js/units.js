/* Conversão e formatação de unidades. Internamente tudo é km, km/h, °C, km/L, L. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const MI = 0.621371;

  const U = {
    speedUnit: () => (CC.get('units.speed') === 'mph' ? 'mph' : 'km/h'),
    distUnit: () => (CC.get('units.speed') === 'mph' ? 'mi' : 'km'),
    tempUnit: () => (CC.get('units.temp') === 'f' ? '°F' : '°C'),
    consUnit: () => ({ kml: 'km/L', l100: 'L/100km', mpg: 'mpg' }[CC.get('units.cons')] || 'km/L'),

    speed: (kmh) => (CC.get('units.speed') === 'mph' ? kmh * MI : kmh),
    dist: (km) => (CC.get('units.speed') === 'mph' ? km * MI : km),
    temp: (c) => (CC.get('units.temp') === 'f' ? c * 1.8 + 32 : c),
    tempDelta: (c) => (CC.get('units.temp') === 'f' ? c * 1.8 : c),
    /** km/L → unidade escolhida */
    cons(kml) {
      if (kml == null || !(kml > 0)) return null;
      const u = CC.get('units.cons');
      if (u === 'l100') return 100 / kml;
      if (u === 'mpg') return kml * 2.35215; // mpg (EUA): 1 km/L = 2,352 mpg
      return kml;
    },
    consDec: () => (CC.get('units.cons') === 'l100' ? 1 : 1),
    /** ex.: speedMax para escala do mostrador */
    speedMax: () => (CC.get('units.speed') === 'mph' ? 160 : 240),
  };
  CC.units = U;
})();
