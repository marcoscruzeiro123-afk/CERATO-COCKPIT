/* Motor de alertas configuráveis: limites, histerese, tempo mínimo de persistência,
 * aviso visual (banner + ícones) e sonoro (WebAudio). */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const U = () => CC.units;

  /* definição das regras; limiares ficam em CC.settings.alerts[id] = {on, v} */
  const RULES = [
    { id: 'coolantCrit', level: 'crit', label: 'Temperatura do motor — CRÍTICA', short: 'Superaquecimento', kind: 'temp', step: 1, min: 95, max: 125, key: 'coolant', dir: 'above', hyst: 3, hold: 1.5 },
    { id: 'coolantWarn', level: 'warn', label: 'Temperatura do motor — atenção', short: 'Motor quente', kind: 'temp', step: 1, min: 85, max: 120, key: 'coolant', dir: 'above', hyst: 2, hold: 2 },
    { id: 'voltLow',  level: 'warn', label: 'Tensão baixa da bateria', short: 'Bateria baixa', kind: 'volt', step: 0.1, min: 10.5, max: 13.0, key: 'voltage', dir: 'below', hyst: 0.3, hold: 4, gate: () => (CC.data.val('rpm') || 0) > 500 || CC.data.val('rpm') == null },
    { id: 'voltHigh', level: 'warn', label: 'Tensão alta (alternador)', short: 'Tensão alta', kind: 'volt', step: 0.1, min: 14.5, max: 16.0, key: 'voltage', dir: 'above', hyst: 0.3, hold: 3 },
    { id: 'iatHigh',  level: 'warn', label: 'Ar de admissão acima da faixa', short: 'Ar de admissão quente', kind: 'temp', step: 1, min: 40, max: 100, key: 'iat', dir: 'above', hyst: 3, hold: 5 },
    { id: 'iatLow',   level: 'warn', label: 'Ar de admissão abaixo da faixa', short: 'Ar de admissão frio', kind: 'temp', step: 1, min: -20, max: 20, key: 'iat', dir: 'below', hyst: 2, hold: 5 },
    { id: 'fuelLow',  level: 'warn', label: 'Combustível baixo', short: 'Combustível baixo', kind: 'pct', step: 1, min: 5, max: 30, key: 'fuelPct', dir: 'below', hyst: 2, hold: 5 },
    { id: 'obdLost',  level: 'crit', label: 'Falha de comunicação com o OBD2', short: 'Sem comunicação OBD2', kind: 'sec', step: 1, min: 2, max: 30, key: null, hold: 0 },
  ];
  CC.ALERT_RULES = RULES;

  const state = {}; // id -> {active, since, muted, lastBeep, beeps}
  RULES.forEach((r) => (state[r.id] = { active: false, pend: 0, muted: false, lastBeep: 0, beeps: 0 }));
  let log = CC.store.read('cerato.alertlog.v1', []);
  let testAlert = null; // {level, until}

  function cfg(id) { return CC.settings.alerts[id]; }

  function fmtVal(r, v) {
    if (r.kind === 'temp') return Math.round(U().temp(v)) + U().tempUnit();
    if (r.kind === 'volt') return v.toFixed(1) + ' V';
    if (r.kind === 'pct') return Math.round(v) + ' %';
    if (r.kind === 'sec') return Math.round(v) + ' s';
    return String(v);
  }
  CC.alertFmt = fmtVal;

  function condition(r, st) {
    const c = cfg(r.id);
    if (!c || !c.on) return false;
    if (r.id === 'obdLost') {
      const L = CC.link.get();
      return (L.state === 'lost' || L.state === 'error') && CC.link.secondsInState() >= c.v;
    }
    if (r.gate && !r.gate()) return false;
    const v = CC.data.val(r.key);
    if (v == null) return false;
    if (r.dir === 'above') return st.active ? v > c.v - r.hyst : v >= c.v;
    return st.active ? v < c.v + r.hyst : v <= c.v;
  }

  function addLog(r, type, text) {
    log.unshift({ t: Date.now(), id: r.id, level: type === 'off' ? 'info' : r.level, text });
    log = log.slice(0, 40);
    CC.store.write('cerato.alertlog.v1', log);
    CC.bus.emit('alertlog');
  }

  function describe(r) {
    const c = cfg(r.id);
    if (r.id === 'obdLost') return 'Sem dados da ECU há ' + Math.round(CC.link.secondsInState()) + ' s';
    const v = CC.data.val(r.key);
    return (v != null ? fmtVal(r, v) : '--') + ' (limite ' + fmtVal(r, c.v) + ')';
  }

  /* ---------- som ---------- */
  let actx = null;
  function audio() {
    if (!actx) { try { actx = new (globalThis.AudioContext || globalThis.webkitAudioContext)(); } catch (e) { actx = false; } }
    if (actx && actx.state === 'suspended') actx.resume();
    return actx;
  }
  function beep(freq, dur, when, vol) {
    const a = audio(); if (!a) return;
    const t0 = a.currentTime + (when || 0);
    const o = a.createOscillator(), g = a.createGain();
    o.type = 'square'; o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(a.destination); o.start(t0); o.stop(t0 + dur + 0.02);
  }
  function sound(level) {
    if (!CC.settings.sound) return;
    const vol = 0.04 + 0.30 * (CC.settings.volume / 100);
    if (level === 'crit') { beep(1250, 0.14, 0, vol); beep(1250, 0.14, 0.2, vol); beep(1250, 0.14, 0.4, vol); }
    else { beep(820, 0.18, 0, vol); beep(620, 0.22, 0.24, vol); }
  }
  CC.alertSound = sound;
  // navegadores exigem gesto do usuário para liberar áudio
  if (typeof addEventListener !== 'undefined') addEventListener('pointerdown', () => { audio(); }, { once: true });

  /* ---------- avaliação (chamada ~5 Hz) ---------- */
  CC.alerts = {
    rules: RULES,
    log: () => log,
    clearLog() { log = []; CC.store.write('cerato.alertlog.v1', log); CC.bus.emit('alertlog'); },
    /** lista de alertas ativos ordenada por gravidade */
    active() {
      const out = RULES.filter((r) => state[r.id].active).map((r) => ({ rule: r, text: describe(r), muted: state[r.id].muted }));
      if (testAlert && Date.now() < testAlert.until) {
        out.push({ rule: { id: 'test', level: testAlert.level, short: 'Teste de alerta', label: 'Teste' }, text: 'Alerta de teste — nenhuma falha real', muted: testAlert.muted });
      }
      out.sort((a, b) => (a.rule.level === b.rule.level ? 0 : a.rule.level === 'crit' ? -1 : 1));
      return out;
    },
    mute() { RULES.forEach((r) => { if (state[r.id].active) state[r.id].muted = true; }); if (testAlert) testAlert.muted = true; CC.bus.emit('alerts'); },
    test(level) { testAlert = { level: level || 'crit', until: Date.now() + 7000, muted: false, lastBeep: 0 }; sound(testAlert.level); CC.bus.emit('alerts'); },
    tick() {
      const now = Date.now();
      let changed = false;
      for (const r of RULES) {
        const st = state[r.id];
        const on = condition(r, st);
        if (on && !st.active) {
          st.pend = st.pend || now;
          if ((now - st.pend) / 1000 >= (r.hold || 0)) {
            st.active = true; st.muted = false; st.beeps = 0; st.lastBeep = 0; changed = true;
            addLog(r, 'on', r.short + ' — ' + describe(r));
          }
        } else if (!on) {
          st.pend = 0;
          if (st.active) { st.active = false; st.muted = false; changed = true; addLog(r, 'off', r.short + ' — normalizado'); }
        }
        // repetição sonora
        if (st.active && !st.muted) {
          const gap = r.level === 'crit' ? 2200 : 15000;
          const maxBeeps = r.level === 'crit' ? 9999 : 3;
          if (now - st.lastBeep > gap && st.beeps < maxBeeps) { st.lastBeep = now; st.beeps++; sound(r.level); }
        }
      }
      if (testAlert) {
        if (now > testAlert.until) { testAlert = null; changed = true; }
        else if (!testAlert.muted && now - testAlert.lastBeep > 2200) { testAlert.lastBeep = now; sound(testAlert.level); }
      }
      if (changed) CC.bus.emit('alerts');
    },
  };
})();
