/* Computador de viagem: duas viagens (A e B), persistidas separadamente para demo e OBD2 real,
 * para que dados simulados nunca contaminem os reais. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});

  function blank() { return { dist: 0, time: 0, moving: 0, vmax: 0, fuel: 0, started: Date.now() }; }

  class Trip {
    constructor(d) { Object.assign(this, blank(), d || {}); }
    avgSpeed() { return this.time > 5 ? this.dist / (this.time / 3600) : null; }          // inclui paradas
    avgMoving() { return this.moving > 5 ? this.dist / (this.moving / 3600) : null; }     // só em movimento
    avgCons() { return this.fuel > 0.05 && this.dist > 0.5 ? this.dist / this.fuel : null; }
    reset() { Object.assign(this, blank()); }
  }

  let profile = 'demo';
  let trips = { A: new Trip(), B: new Trip() };
  let active = 'A';
  let lastSave = 0;

  function key() { return 'cerato.trips.v1.' + profile; }
  function load() {
    const s = CC.store.read(key(), null);
    trips = { A: new Trip(s && s.A), B: new Trip(s && s.B) };
  }
  function save() { CC.store.write(key(), { A: trips.A, B: trips.B }); }

  CC.trip = {
    get: (n) => trips[n || active],
    both: () => trips,
    useProfile(p) { if (p === profile) return; save(); profile = p; load(); CC.fuelModel.profile = p; CC.fuelModel.load(p); },
    init(p) { profile = p; load(); CC.fuelModel.profile = p; CC.fuelModel.load(p); },
    reset(n) { trips[n].reset(); save(); CC.bus.emit('trip', n); },
    resetAll() { trips.A.reset(); trips.B.reset(); save(); CC.bus.emit('trip', 'all'); },
    /** chamado a ~10 Hz: speed km/h (ou null), rate L/h (ou null) */
    integrate(dt, speed, rate) {
      if (!(dt > 0) || dt > 2) return;
      if (speed == null) return;
      for (const t of [trips.A, trips.B]) {
        t.time += dt;
        t.dist += (speed * dt) / 3600;
        if (speed > 1) t.moving += dt;
        if (speed > t.vmax) t.vmax = speed;
        if (rate != null) t.fuel += (rate * dt) / 3600;
      }
      const now = Date.now();
      if (now - lastSave > 10000) { lastSave = now; save(); }
    },
    save,
  };
  if (typeof addEventListener !== 'undefined') {
    addEventListener('pagehide', save);
    addEventListener('visibilitychange', () => { if (document.hidden) save(); });
  }
})();
