/* Configurações persistentes (localStorage com fallback em memória). */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const KEY = 'cerato.settings.v1';

  const DEFAULTS = {
    theme: 'ice',            // ice | sport | eco | amber
    brightness: 100,         // 30..100
    brightnessAuto: false,   // reduz à noite (18h–6h)
    units: { speed: 'kmh', temp: 'c', cons: 'kml' },
    source: 'demo',          // demo | obd
    transport: 'auto',       // auto | bridge | webbt | emulator
    device: { name: '', address: '' },
    protocol: '0',           // ATSP: 0 = automático
    pollRate: 'normal',      // lento | normal | rapido
    vehicle: {
      tankL: 50,             // capacidade do tanque (L) — ajuste conforme seu carro
      dispCc: 1591,          // cilindrada (cm³)
      ve: 80,                // eficiência volumétrica assumida (%) p/ estimativa por MAP
      fuel: 'flex_gas',      // flex_gas | ethanol | gasoline
      tire: 1.99,            // circunferência do pneu (m) — 205/55 R16 ≈ 1,99 m
      gearEst: true,         // estimar marcha
    },
    sound: true,
    volume: 70,
    alerts: {
      coolantWarn: { on: true,  v: 98 },
      coolantCrit: { on: true,  v: 105 },
      voltLow:     { on: true,  v: 12.0 },
      voltHigh:    { on: true,  v: 15.0 },
      iatHigh:     { on: true,  v: 70 },
      iatLow:      { on: false, v: -5 },
      fuelLow:     { on: true,  v: 10 },
      obdLost:     { on: true,  v: 6 },
    },
  };

  // Combustíveis: relação ar/combustível estequiométrica e densidade (g/L) — valores aproximados.
  CC.FUELS = {
    flex_gas: { label: 'Gasolina (E27)', afr: 13.2, dens: 750 },
    ethanol:  { label: 'Etanol',         afr: 9.0,  dens: 790 },
    gasoline: { label: 'Gasolina pura',  afr: 14.7, dens: 745 },
  };

  // Relações de marcha (câmbio automático 6 marchas) e diferencial — valores de REFERÊNCIA.
  // A marcha mostrada no painel é sempre uma ESTIMATIVA (rpm ÷ velocidade); ajuste se necessário.
  CC.GEARS = { ratios: [4.162, 2.372, 1.552, 1.158, 0.851, 0.672], finalDrive: 3.51 };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function merge(base, over) {
    if (over == null || typeof over !== 'object') return base;
    for (const k of Object.keys(base)) {
      if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) merge(base[k], over[k]);
      else if (over[k] !== undefined && typeof over[k] === typeof base[k]) base[k] = over[k];
    }
    return base;
  }

  let mem = null;
  function load() {
    let raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { raw = mem; }
    let obj = {};
    try { obj = raw ? JSON.parse(raw) : {}; } catch (e) { obj = {}; }
    return merge(clone(DEFAULTS), obj);
  }

  CC.settings = load();
  CC.settings.save = undefined;
  let timer = null;
  CC.saveSettings = function () {
    clearTimeout(timer);
    timer = setTimeout(() => {
      const s = JSON.stringify(CC.settings);
      try { localStorage.setItem(KEY, s); } catch (e) { mem = s; }
    }, 150);
  };
  /** altera uma chave por caminho "a.b.c" e avisa a interface. */
  CC.set = function (path, value) {
    const parts = path.split('.');
    let o = CC.settings;
    for (let i = 0; i < parts.length - 1; i++) o = o[parts[i]];
    o[parts[parts.length - 1]] = value;
    CC.saveSettings();
    CC.bus.emit('settings', path, value);
  };
  CC.get = function (path) {
    return path.split('.').reduce((o, k) => (o == null ? o : o[k]), CC.settings);
  };
  CC.DEFAULTS = DEFAULTS;

  /* armazenamento genérico (viagens etc.) */
  CC.store = {
    read(k, fallback) { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : fallback; } catch (e) { return fallback; } },
    write(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignora */ } },
  };
})();
