/* Inicialização e orquestração: escolhe a fonte de dados (demo | OBD2) e roda os laços periódicos.
 * Trocar de fonte NÃO altera a interface — ela só lê CC.data / CC.link. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});

  CC.app = {
    /** mode: 'demo' | 'obd'. interactive = veio de um toque (necessário p/ Web Bluetooth). */
    setSource(mode, interactive) {
      CC.set('source', mode);
      if (mode === 'demo') {
        CC.obd.halt();
        CC.demo.stop();
        CC.data.clear();
        CC.trip.useProfile('demo');
        CC.demo.start();
      } else {
        CC.demo.stop();
        CC.trip.useProfile('obd');
        CC.obd.start(!!interactive);
      }
      CC.bus.emit('source', mode);
    },
  };

  function boot() {
    CC.trip.init(CC.settings.source === 'obd' ? 'obd' : 'demo');
    CC.shell.init();
    CC.dash.init();
    CC.gauges.start();
    CC.engineScreen.init();
    setInterval(() => { CC.derivedUpdate(); }, 100);
    setInterval(() => { CC.alerts.tick(); }, 200);
    // Modo OBD2 salvo: tenta reconectar sozinho (Web Bluetooth precisa de toque e avisa na tela).
    if (CC.settings.source === 'obd') { CC.demo.stop(); CC.obd.start(false); }
    else CC.demo.start();
    // tela cheia imersiva quando o navegador permitir (um toque)
    const fs = () => { const d = document.documentElement; if (!document.fullscreenElement && d.requestFullscreen && !/[?&]nofs/.test(location.search)) d.requestFullscreen().catch(() => {}); };
    addEventListener('pointerdown', fs, { once: true });
    // mantém a tela acesa quando suportado
    try { if (navigator.wakeLock) navigator.wakeLock.request('screen').catch(() => {}); } catch (e) { /* ignora */ }
    document.addEventListener('visibilitychange', () => { try { if (!document.hidden && navigator.wakeLock) navigator.wakeLock.request('screen').catch(() => {}); } catch (e) { /* ignora */ } });
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
