/* Tela Alertas: estado atual, histórico e regras configuráveis (limite + liga/desliga). */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const el = CC.util.el, U = () => CC.units;
  let root;
  const $ = (id) => root.querySelector('#' + id);
  const hhmm = (t) => { const d = new Date(t); return CC.util.pad2(d.getHours()) + ':' + CC.util.pad2(d.getMinutes()) + ':' + CC.util.pad2(d.getSeconds()); };

  function renderState() {
    if (!root) return;
    const act = CC.alerts.active(), s = $('st');
    const top = act[0];
    s.className = 'panel state' + (top ? (top.rule.level === 'crit' ? ' crit' : ' warn') : '');
    $('stT').textContent = top ? top.rule.short + (act.length > 1 ? ' (+' + (act.length - 1) + ')' : '') : 'Tudo normal';
    $('stS').textContent = top ? top.text : 'Nenhum alerta ativo no momento.';
  }
  function renderLog() {
    if (!root) return;
    const box = $('logRows'); box.innerHTML = '';
    const log = CC.alerts.log().slice(0, 7);
    if (!log.length) { box.appendChild(el('div', 'empty', 'Nenhum evento registrado.')); return; }
    log.forEach((e) => box.appendChild(el('div', 'lrow' + (e.level === 'info' ? ' off' : ''),
      '<time>' + hhmm(e.t) + '</time><i class="dotc ' + e.level + '"></i><span>' + e.text + '</span>')));
  }

  /* converte limites entre °C (interno) e a unidade exibida */
  function ruleRow(r) {
    const c = CC.settings.alerts[r.id];
    const isTemp = r.kind === 'temp', f = (v) => (isTemp ? Math.round(U().temp(v)) : v);
    const unit = () => (isTemp ? U().tempUnit() : r.kind === 'volt' ? 'V' : r.kind === 'pct' ? '%' : 's');
    const row = el('div', 'rrow');
    const nm = el('div', 'rn', r.label + '<small>' + (r.id === 'obdLost' ? 'tempo sem resposta' : r.dir === 'above' ? 'dispara acima de' : 'dispara abaixo de') + '</small>');
    const st = CC.w.stepper({
      value: c.v, min: r.min, max: r.max, step: r.step,
      fmt: (v) => (isTemp ? Math.round(U().temp(v)) : r.step < 1 ? v.toFixed(1) : Math.round(v)) + '<small>' + unit() + '</small>',
      onChange: (v) => { CC.set('alerts.' + r.id + '.v', v); if (r.id === 'coolantWarn' || r.id === 'coolantCrit') ensureOrder(r.id); },
    });
    row.append(nm, st, CC.w.toggle(c.on, (on) => CC.set('alerts.' + r.id + '.on', on)));
    row._st = st;
    return row;
  }
  /* o limite crítico nunca pode ficar abaixo do de atenção */
  function ensureOrder(changed) {
    const a = CC.settings.alerts;
    if (a.coolantCrit.v <= a.coolantWarn.v) {
      if (changed === 'coolantWarn') CC.set('alerts.coolantCrit.v', a.coolantWarn.v + 1);
      else CC.set('alerts.coolantWarn.v', a.coolantCrit.v - 1);
      refreshSteppers();
    }
  }
  let rowEls = {};
  function refreshSteppers() { for (const id in rowEls) rowEls[id]._st.setValue(CC.settings.alerts[id].v); }

  CC.alertsScreen = {
    mount(host) {
      root = host; host.classList.add('sub');
      const hdr = el('div', 'hdr', '<h1>Alertas</h1><span class="grow"></span>');
      hdr.append(
        CC.w.btn('Testar aviso', 'sm', () => CC.alerts.test('warn')),
        CC.w.btn('Testar crítico', 'sm danger', () => CC.alerts.test('crit')),
        CC.w.btn('Silenciar', 'sm', () => CC.alerts.mute())
      );
      const grid = el('div', 'alr');
      const left = el('div', 'left');
      left.innerHTML = '<div class="panel state" id="st"><i class="led"></i><div><b id="stT">--</b><span id="stS"></span></div></div>'
        + '<div class="panel log"><h3>Histórico</h3><div id="logRows"></div></div>';
      const sound = el('div', 'panel', '');
      sound.style.cssText = 'padding:12px 24px;display:flex;align-items:center;gap:20px;flex-wrap:nowrap';
      sound.append(el('span', 'rn', 'Alerta sonoro'), CC.w.toggle(CC.settings.sound, (v) => CC.set('sound', v)),
        el('span', 'lbl', 'Volume'),
        CC.w.stepper({ value: CC.settings.volume, min: 10, max: 100, step: 10, fmt: (v) => v + '<small>%</small>', onChange: (v) => { CC.set('volume', v); CC.alertSound('warn'); } }));
      sound.firstChild.style.cssText = 'flex:1;font-size:23px';
      left.appendChild(sound);
      const rules = el('div', 'panel rules'); rules.appendChild(el('h3', '', 'Limites'));
      CC.alerts.rules.forEach((r) => { const w = ruleRow(r); rowEls[r.id] = w; rules.appendChild(w); });
      grid.append(left, rules); host.append(hdr, grid);
      CC.bus.on('alerts', renderState); CC.bus.on('alertlog', renderLog);
      CC.bus.on('settings', (p) => { if (p === 'units.temp') { for (const id in rowEls) rowEls[id]._st.setValue(CC.settings.alerts[id].v); } });
      renderState(); renderLog();
    },
    show() { renderState(); renderLog(); refreshSteppers(); },
  };
})();
