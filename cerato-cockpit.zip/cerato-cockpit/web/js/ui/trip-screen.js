/* Tela Computador de Viagem (viagens A e B). */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const el = CC.util.el, U = () => CC.units;
  let root, which = 'A', timer = null, ring, F = {};

  function metric(id, label) {
    const m = el('div', 'panel metric', '<label>' + label + ' <span id="tq_' + id + '"></span></label><div class="mv" id="tv_' + id + '">--</div>');
    return m;
  }
  const $ = (id) => root.querySelector('#' + id);
  function set(id, v, unit) { $('tv_' + id).innerHTML = v + (unit ? '<small>' + unit + '</small>' : ''); }
  function q(id, qual) { $('tq_' + id).innerHTML = qual === 'sim' || qual === 'est' ? CC.w.qtag(qual) : ''; }
  const hms = (s) => { s = Math.floor(s); return CC.util.pad2(Math.floor(s / 3600)) + ':' + CC.util.pad2(Math.floor(s / 60) % 60) + ':' + CC.util.pad2(s % 60); };

  function update() {
    if (!root) return;
    const t = CC.trip.get(which), u = U(), D = CC.data;
    const fq = D.quality('avgCons') === 'sim' || D.quality('speed') === 'sim' ? 'sim' : D.quality('fuelRate') === 'est' ? 'est' : '';
    const dq = D.quality('speed') === 'sim' ? 'sim' : '';
    set('dist', CC.util.fmt(u.dist(t.dist), 1), u.distUnit()); q('dist', dq);
    set('time', hms(t.time)); 
    const av = t.avgSpeed();
    set('avg', av == null ? '--' : Math.round(u.speed(av)), u.speedUnit()); q('avg', dq);
    set('max', Math.round(u.speed(t.vmax)), u.speedUnit()); q('max', dq);
    const c = u.cons(t.avgCons());
    set('cons', c == null ? '--' : c.toFixed(1), u.consUnit()); q('cons', fq);
    set('fuel', t.fuel > 0 ? t.fuel.toFixed(1) : '--', 'L'); q('fuel', fq);
    const r = D.val('range');
    $('rv').textContent = r == null ? '--' : Math.round(u.dist(r));
    $('ru').textContent = u.distUnit();
    $('rq').innerHTML = CC.w.qtag(D.quality('range') === 'na' ? 'na' : D.quality('range'));
    ring.set(D.val('fuelPct'));
    $('rfl').textContent = D.val('fuelL') == null ? 'nível não informado' : D.val('fuelL').toFixed(1) + ' L no tanque';
  }

  CC.tripScreen = {
    mount(host) {
      root = host; host.classList.add('sub');
      const hdr = el('div', 'hdr', '<h1>Computador de Viagem</h1><span class="grow"></span>');
      hdr.appendChild(CC.w.seg([['A', 'Viagem A'], ['B', 'Viagem B']], which, (v) => { which = v; update(); }));
      const grid = el('div', 'trip');
      const L = el('div', 'col'), M = el('div', 'panel ring'), R = el('div', 'col');
      L.append(metric('dist', 'DISTÂNCIA'), metric('time', 'TEMPO DE VIAGEM'), metric('avg', 'VELOCIDADE MÉDIA'));
      R.append(metric('max', 'VELOCIDADE MÁXIMA'), metric('cons', 'CONSUMO MÉDIO'), metric('fuel', 'COMBUSTÍVEL CONSUMIDO (EST.)'));
      M.innerHTML = '<div class="ringbox"><div class="rc"><label>AUTONOMIA <span id="rq"></span></label><b id="rv">--</b><span id="ru">km</span></div></div>'
        + '<div class="lbl" id="rfl" style="margin-top:6px">--</div>';
      ring = CC.gauges.arcGauge(M.querySelector('.ringbox'), {
        size: 460, r: 200, w: 26, min: 0, max: 100,
        zones: [{ from: 0, to: 12, color: 'var(--crit)' }],
      });
      const act = el('div', 'trip-actions');
      act.append(
        CC.w.btn('Zerar viagem atual', 'danger wide', () => { if (confirmReset()) { CC.trip.reset(which); update(); } }),
        CC.w.btn('Tanque cheio', 'wide', () => { CC.fuelModel.setFull(); update(); })
      );
      M.appendChild(act);
      // rótulo do botão acompanha A/B
      const rb = act.firstChild; rb.id = 'btnResetTrip';
      grid.append(L, M, R);
      host.append(hdr, grid);
      this.show();
    },
    show() { update(); clearInterval(timer); timer = setInterval(update, 500); },
    hide() { clearInterval(timer); },
  };

  /* confirmação em dois toques (sem diálogo nativo, que não combina com tela cheia) */
  let armed = 0;
  function confirmReset() {
    const b = document.getElementById('btnResetTrip');
    if (Date.now() - armed < 3000) { armed = 0; b.textContent = 'Zerar viagem atual'; return true; }
    armed = Date.now(); b.textContent = 'Toque de novo p/ confirmar';
    setTimeout(() => { if (armed && Date.now() - armed >= 2900) { armed = 0; b.textContent = 'Zerar viagem atual'; } }, 3100);
    return false;
  }
})();
