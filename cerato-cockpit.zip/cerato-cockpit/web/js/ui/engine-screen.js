/* Tela Monitor do Motor: temperatura em destaque, mini-mostradores, histórico e parâmetros da ECU. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const el = CC.util.el, U = () => CC.units, D = () => CC.data;
  let root, timer = null, big, minis = {}, hist = [], histTimer = null, rows = {}, chartPath, chartWarn, chartCrit, chartLbl;
  const HN = 150; // 150 amostras = 2,5 min
  const $ = (id) => root.querySelector('#' + id);

  /* parâmetros adicionais (barra proporcional min..max) */
  const EXTRA = [
    ['load', 0, 100], ['throttle', 0, 100], ['map', 0, 255], ['maf', 0, 60],
    ['timing', -10, 50], ['stft', -25, 25], ['ltft', -25, 25],
  ];
  const EXTRA_LABEL = { fuelRate: ['Vazão de combustível', 'L/h'] };

  function mini(host, key, label, o) {
    const w = el('div', 'panel mini', '<div class="gwrap"><div class="gv"><span class="v">--</span><small>' + o.unit + '</small></div></div><div class="gl">' + label + ' <span class="qt"></span></div>');
    const g = CC.gauges.arcGauge(w.querySelector('.gwrap'), { size: 210, r: 84, w: 15, min: o.min, max: o.max, zones: o.zones });
    host.appendChild(w);
    minis[key] = { g, v: w.querySelector('.v'), u: w.querySelector('small'), qt: w.querySelector('.qt'), o };
  }

  function sample() {
    const c = D().val('coolant');
    hist.push(c == null ? null : c); if (hist.length > HN) hist.shift();
  }

  function drawChart() {
    const W = 800, H = 200, u = U();
    const lo = 40, hi = 125, y = (c) => H - 14 - ((CC.util.clamp(c, lo, hi) - lo) / (hi - lo)) * (H - 28);
    let d = '', pen = false;
    hist.forEach((c, i) => {
      if (c == null) { pen = false; return; }
      const x = (i / (HN - 1)) * W + (W - (hist.length - 1) / (HN - 1) * W);
      d += (pen ? 'L' : 'M') + x.toFixed(1) + ',' + y(c).toFixed(1); pen = true;
    });
    chartPath.setAttribute('d', d);
    const a = CC.get('alerts');
    chartWarn.setAttribute('y1', y(a.coolantWarn.v)); chartWarn.setAttribute('y2', y(a.coolantWarn.v));
    chartCrit.setAttribute('y1', y(a.coolantCrit.v)); chartCrit.setAttribute('y2', y(a.coolantCrit.v));
    const vals = hist.filter((v) => v != null);
    chartLbl.textContent = vals.length ? 'mín ' + Math.round(u.temp(Math.min(...vals))) + ' · máx ' + Math.round(u.temp(Math.max(...vals))) + ' ' + u.tempUnit() : 'sem dados';
  }

  function update() {
    if (!root) return;
    const u = U(), d = D(), a = CC.get('alerts');
    /* temperatura (grande) */
    const c = d.val('coolant');
    const lvl = c == null ? '' : c >= a.coolantCrit.v ? 'crit' : c >= a.coolantWarn.v ? 'warn' : c < 60 ? 'cold' : 'ok';
    $('bigv').textContent = c == null ? '--' : Math.round(u.temp(c));
    $('bigu').textContent = u.tempUnit();
    const st = { crit: ['CRÍTICA', 'var(--crit)'], warn: ['ELEVADA', 'var(--warn)'], cold: ['MOTOR FRIO', 'var(--accent2)'], ok: ['NORMAL', 'var(--ok)'], '': ['SEM DADO', 'var(--dim)'] }[lvl];
    const bs = $('bigs'); bs.textContent = st[0]; bs.style.color = st[1];
    $('bigq').innerHTML = CC.w.qtag(d.quality('coolant'));
    big.set(c);
    /* mini-mostradores */
    const vals = { rpm: d.val('rpm'), voltage: d.val('voltage'), iat: d.val('iat') };
    for (const k in minis) {
      const m = minis[k], v = k === 'iat' && vals[k] != null ? u.temp(vals[k]) : vals[k];
      const col = k === 'rpm' && vals.rpm > 6000 ? 'var(--crit)' : k === 'voltage' && vals.voltage != null && vals.voltage < a.voltLow.v ? 'var(--warn)' : null;
      m.g.set(vals[k] == null ? null : (k === 'iat' ? vals[k] : vals[k]));
      m.v.textContent = v == null ? '--' : v.toFixed(k === 'voltage' ? 1 : 0);
      if (k === 'iat') m.u.textContent = u.tempUnit();
      m.qt.innerHTML = d.quality(k) === 'real' ? '' : CC.w.qtag(d.quality(k));
    }
    /* parâmetros */
    EXTRA.forEach(([k, lo, hi]) => {
      const r = rows[k], v = d.val(k), q = d.quality(k);
      const p = CC.PARAMS[k];
      const dec = p ? p.dec : 1;
      r.row.classList.toggle('nav', v == null);
      r.pv.innerHTML = v == null ? (q === 'na' ? 'indisponível' : '--') : v.toFixed(dec) + '<small>' + r.unit + '</small>';
      r.pq.innerHTML = v == null ? '' : (q === 'real' ? '' : CC.w.qtag(q));
      r.bar.style.width = v == null ? '0%' : Math.round(CC.util.clamp((v - lo) / (hi - lo), 0, 1) * 100) + '%';
    });
    const g = d.val('gear');
    $('gearEng').textContent = g == null ? '--' : g + 'ª (estimada)';
  }

  function buildRows(host) {
    EXTRA.forEach(([k]) => {
      const p = CC.PARAMS[k] || {}, lb = EXTRA_LABEL[k] || [p.label, p.unit];
      const row = el('div', 'prow', '<span class="pn">' + lb[0] + ' <span class="pq"></span></span><span class="pv">--</span><div class="pb"><i></i></div>');
      host.appendChild(row);
      rows[k] = { row, pv: row.querySelector('.pv'), pq: row.querySelector('.pq'), bar: row.querySelector('.pb i'), unit: lb[1] };
    });
  }

  async function readDtc() {
    const box = $('dtcBox');
    if (CC.link.get().mode !== 'obd') { box.innerHTML = 'Leitura de falhas só está disponível com o <b>OBD2 real</b> conectado (modo demonstração não tem ECU).'; return; }
    box.textContent = 'Lendo…';
    try {
      const mil = await CC.obd.readMil(), dtc = await CC.obd.readDtc();
      box.innerHTML = (mil && mil.on ? '<b>Luz MIL acesa.</b> ' : 'Luz MIL apagada. ') + (dtc.length ? 'Códigos: <b>' + dtc.join(', ') + '</b>' : 'Nenhum código armazenado.');
    } catch (e) { box.textContent = 'Não foi possível ler: ' + (e.message || e); }
  }

  CC.engineScreen = {
    /** histórico de temperatura corre desde a abertura do app, mesmo com a tela fechada */
    init() { if (!histTimer) histTimer = setInterval(sample, 1000); },
    mount(host) {
      root = host; host.classList.add('sub');
      host.appendChild(el('div', 'hdr', '<h1>Monitor do Motor</h1><small>Marcha: <span id="gearEng">--</span></small><span class="grow"></span><small id="engSrc"></small>'));
      const grid = el('div', 'eng');
      /* esquerda — temperatura */
      const L = el('div', 'panel big-gauge');
      L.innerHTML = '<div class="lbl" style="font-size:26px">TEMPERATURA DO MOTOR <span id="bigq"></span></div>'
        + '<div class="ringbox"><div class="rc"><b id="bigv" style="font-size:120px">--</b><span id="bigu">°C</span></div></div>'
        + '<div id="bigs" style="font-size:34px;font-weight:700;letter-spacing:2px">--</div>';
      big = CC.gauges.arcGauge(L.querySelector('.ringbox'), {
        size: 430, r: 178, w: 28, min: 40, max: 125,
        zones: [{ from: 40, to: 60, color: 'var(--accent2)' }, { from: 60, to: 98, color: 'var(--ok)' }, { from: 98, to: 105, color: 'var(--warn)' }, { from: 105, to: 125, color: 'var(--crit)' }],
        color: 'var(--ok)',
      });
      /* centro — mini-mostradores + histórico */
      const M = el('div', 'mid'), mins = el('div', 'minis');
      mini(mins, 'rpm', 'Rotação', { unit: 'rpm', min: 0, max: 8000, zones: [{ from: 6500, to: 8000, color: 'var(--crit)' }] });
      mini(mins, 'voltage', 'Bateria', { unit: 'V', min: 9, max: 16, zones: [{ from: 9, to: 12, color: 'var(--warn)' }, { from: 15, to: 16, color: 'var(--warn)' }] });
      mini(mins, 'iat', 'Ar adm.', { unit: '°C', min: -10, max: 80, zones: [{ from: 70, to: 80, color: 'var(--warn)' }] });
      const ch = el('div', 'panel chart');
      ch.innerHTML = '<div class="ct"><span>TEMPERATURA · últimos 2,5 min</span><span id="chLbl"></span></div>'
        + '<svg viewBox="0 0 800 200" preserveAspectRatio="none"><line id="chW" x1="0" x2="800" stroke="var(--warn)" stroke-dasharray="6 6" opacity=".7"/><line id="chC" x1="0" x2="800" stroke="var(--crit)" stroke-dasharray="6 6" opacity=".8"/>'
        + '<path id="chP" fill="none" style="stroke:var(--accent2)" stroke-width="3.2" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>';
      M.append(mins, ch);
      /* direita — parâmetros */
      const R = el('div', 'panel side');
      buildRows(R);
      R.appendChild(el('div', 'dtc', '<div style="display:flex;justify-content:space-between;align-items:center"><span class="lbl">FALHAS (DTC)</span></div><div id="dtcBox" style="margin-top:6px">Toque em “Ler falhas”.</div>'));
      R.querySelector('.dtc>div').appendChild(CC.w.btn('Ler falhas', 'sm', readDtc));
      grid.append(L, M, R); host.appendChild(grid);
      chartPath = $('chP'); chartWarn = $('chW'); chartCrit = $('chC'); chartLbl = $('chLbl');
      this.show();
    },
    show() { update(); drawChart(); clearInterval(timer); timer = setInterval(() => { update(); drawChart(); }, 500); },
    hide() { clearInterval(timer); },
  };
})();
