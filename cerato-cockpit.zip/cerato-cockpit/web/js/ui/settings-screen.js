/* Tela Configurações: aparência, unidades, fonte de dados, adaptador OBD2 e veículo. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const el = CC.util.el;
  let root, body, page = 'look', menuBtns = {}, timer = null, pageTimer = null;

  const PAGES = [['look', 'Aparência'], ['units', 'Unidades'], ['src', 'Fonte de dados'], ['obd', 'Adaptador OBD2'], ['veh', 'Veículo']];
  const THEMES = [['ice', 'Gelo', 'linear-gradient(135deg,#0a3fb0,#55d2ff)'], ['sport', 'Esporte', 'linear-gradient(135deg,#a3140d,#ff9a5a)'],
    ['eco', 'Eco', 'linear-gradient(135deg,#087a4a,#7dffc4)'], ['amber', 'Âmbar', 'linear-gradient(135deg,#a35a00,#ffd27a)']];

  function row(name, sub, ctl, wrap) {
    const r = el('div', 'frow' + (wrap ? ' wrap' : ''), '<div class="fn">' + name + (sub ? '<small>' + sub + '</small>' : '') + '</div>');
    if (ctl) r.appendChild(ctl);
    return r;
  }
  const step = (path, o) => CC.w.stepper(Object.assign({ value: CC.get(path), onChange: (v) => CC.set(path, v) }, o));

  /* ---------- páginas ---------- */
  const build = {
    look() {
      const th = el('div', 'themes');
      THEMES.forEach(([id, nm, bg]) => {
        const s = el('button', 'sw' + (CC.settings.theme === id ? ' on' : ''), nm); s.style.background = bg;
        s.addEventListener('click', () => { CC.set('theme', id); th.querySelectorAll('.sw').forEach((x) => x.classList.toggle('on', x === s)); });
        th.appendChild(s);
      });
      return [
        row('Tema visual', 'cor de destaque dos mostradores', th),
        row('Brilho da interface', 'escurece a tela por software', step('brightness', { min: 30, max: 100, step: 5, fmt: (v) => v + '<small>%</small>' })),
        row('Brilho automático à noite', 'reduz das 18h às 6h', CC.w.toggle(CC.settings.brightnessAuto, (v) => CC.set('brightnessAuto', v))),
      ];
    },
    units() {
      return [
        row('Velocidade e distância', '', CC.w.seg([['kmh', 'km/h'], ['mph', 'mph']], CC.get('units.speed'), (v) => CC.set('units.speed', v))),
        row('Temperatura', '', CC.w.seg([['c', '°C'], ['f', '°F']], CC.get('units.temp'), (v) => CC.set('units.temp', v))),
        row('Consumo', '', CC.w.seg([['kml', 'km/L'], ['l100', 'L/100km'], ['mpg', 'mpg']], CC.get('units.cons'), (v) => CC.set('units.cons', v))),
      ];
    },
    src() {
      const L = CC.link.get();
      const state = el('div', 'big-state', ''); state.id = 'bigState';
      const sc = CC.w.seg(CC.demo.scenarios.map((s) => [s.id, s.label]), CC.demo.scenario(), (v) => CC.demo.setScenario(v));
      const stats = el('div', 'statgrid'); stats.id = 'stats';
      const acts = el('div', '');
      acts.style.cssText = 'display:flex;gap:14px';
      acts.append(
        CC.w.btn('Conectar OBD2', 'primary', () => CC.app.setSource('obd', true)),
        CC.w.btn('Desconectar', '', () => { CC.obd.stop(); }),
        CC.w.btn('Voltar à demonstração', '', () => CC.app.setSource('demo'))
      );
      const r = [
        row('Fonte dos dados', 'DEMONSTRAÇÃO usa valores simulados; OBD2 lê o carro de verdade',
          CC.w.seg([['demo', 'Demonstração'], ['obd', 'OBD2 real']], CC.settings.source, (v) => CC.app.setSource(v, true))),
        row('Estado da conexão', '', state),
      ];
      if (CC.settings.source === 'demo') r.push(row('Cenário da demonstração', 'para testar alertas e animações', sc, true));
      else r.push(row('Ações', '', acts, true));
      r.push(stats);
      r.push(el('div', 'note', 'Cada valor mostra sua origem: sem etiqueta = lido da ECU · <span class="q sim">SIM</span> simulado · <span class="q est">EST</span> estimado · <span class="q na">N/D</span> a ECU não informa. Nada é inventado.'));
      return r;
    },
    obd() {
      const T = CC.transports || {};
      const opts = [['auto', 'Automático']];
      if (T.bridge) opts.push(['bridge', 'App Android']);
      if (T.webbt) opts.push(['webbt', 'Web Bluetooth']);
      opts.push(['emulator', 'Emulado']);
      const dev = el('div', 'devlist'); dev.id = 'devs';
      const con = el('div', 'console'); con.id = 'console';
      const r = [
        row('Ponte de comunicação', 'Bluetooth clássico (a maioria dos ELM327) exige o app Android', CC.w.seg(opts, CC.settings.transport, (v) => { CC.set('transport', v); loadDevices(); })),
        row('Protocolo', 'automático costuma funcionar no Cerato (ISO 15765 / CAN)', CC.w.seg([['0', 'Auto'], ['6', 'CAN 11/500'], ['7', 'CAN 29/500'], ['3', 'ISO 9141']], CC.settings.protocol, (v) => CC.set('protocol', v))),
        row('Velocidade de leitura', 'rápido atualiza mais, mas exige adaptador bom', CC.w.seg([['lento', 'Lenta'], ['normal', 'Normal'], ['rapido', 'Rápida']], CC.settings.pollRate, (v) => CC.set('pollRate', v))),
        row('Adaptador pareado', '', null),
        dev, con,
      ];
      setTimeout(loadDevices, 0);
      return r;
    },
    veh() {
      return [
        row('Capacidade do tanque', 'ajuste conforme o seu carro', step('vehicle.tankL', { min: 30, max: 80, step: 1, fmt: (v) => v + '<small>L</small>' })),
        row('Combustível usado', 'afeta a estimativa de consumo', CC.w.seg([['flex_gas', 'Gasolina'], ['ethanol', 'Etanol'], ['gasoline', 'G. pura']], CC.get('vehicle.fuel'), (v) => CC.set('vehicle.fuel', v))),
        row('Circunferência do pneu', 'usada para estimar a marcha', step('vehicle.tire', { min: 1.7, max: 2.3, step: 0.01, fmt: (v) => v.toFixed(2) + '<small>m</small>' })),
        row('Marcha estimada', 'rpm ÷ velocidade — não vem da ECU', CC.w.toggle(CC.get('vehicle.gearEst'), (v) => CC.set('vehicle.gearEst', v))),
        row('Eficiência volumétrica', 'só para estimar consumo quando a ECU não tem MAF', step('vehicle.ve', { min: 60, max: 100, step: 1, fmt: (v) => v + '<small>%</small>' })),
        row('Restaurar padrões', 'volta todas as configurações ao original', CC.w.btn('Restaurar', 'sm danger', () => {
          try { localStorage.removeItem('cerato.settings.v1'); } catch (e) { /* ignora */ }
          location.reload();
        })),
      ];
    },
  };

  async function loadDevices() {
    const box = root.querySelector('#devs'); if (!box) return;
    box.innerHTML = '';
    const tr = CC.obd.pick();
    if (!tr) { box.appendChild(el('div', 'empty', 'Nenhuma ponte disponível neste aparelho. Use o app Android ou o modo Emulado.')); return; }
    if (tr.id === 'webbt') { box.appendChild(el('div', 'empty', 'O navegador abrirá a lista de dispositivos ao tocar em “Conectar OBD2”.')); return; }
    const list = await tr.listDevices();
    if (!list.length) box.appendChild(el('div', 'empty', 'Nenhum dispositivo pareado. Pareie o ELM327 em Ajustes › Bluetooth do Android (senha 1234 ou 0000).'));
    list.forEach((d) => {
      const b = el('button', 'dev' + (CC.settings.device.address === d.address ? ' on' : ''), '<span>' + d.name + '</span><small>' + d.address + '</small>');
      b.addEventListener('click', () => { CC.set('device', { name: d.name, address: d.address }); box.querySelectorAll('.dev').forEach((x) => x.classList.toggle('on', x === b)); });
      box.appendChild(b);
    });
  }

  /* ---------- atualização ao vivo (status e console) ---------- */
  function live() {
    const bs = root.querySelector('#bigState');
    if (bs) {
      const L = CC.link.get();
      const map = { idle: ['Desconectado', 'err'], connecting: ['Conectando…', 'busy'], ready: [L.mode === 'demo' ? 'Demonstração (dados simulados)' : 'OBD2 conectado — dados reais', L.mode === 'demo' ? 'sim' : 'real'], lost: ['Sem sinal', 'err'], error: ['Erro de conexão', 'err'] };
      const m = map[L.state] || map.idle; bs.textContent = m[0]; bs.className = 'big-state ' + m[1];
      const st = root.querySelector('#stats');
      if (st) {
        const items = [['Modo', L.mode === 'demo' ? 'Demonstração' : 'OBD2'], ['Mensagem', L.info || '—'], ['Ponte', L.transport || '—'],
          ['Adaptador', L.version || '—'], ['Protocolo', L.protocol || '—'], ['Há', Math.round(CC.link.secondsInState()) + ' s neste estado']];
        const html = items.map((i) => '<div class="stat"><span>' + i[0] + '</span><span>' + i[1] + '</span></div>').join('');
        if (st._h !== html) { st._h = html; st.innerHTML = html; }
      }
    }
    const c = root.querySelector('#console');
    if (c) { const t = CC.obd.logLines().slice(-9).join('\n') || 'Console do adaptador (aparece ao conectar).'; if (c._t !== t) { c._t = t; c.textContent = t; } }
  }

  function showPage(p) {
    page = p;
    for (const k in menuBtns) menuBtns[k].classList.toggle('on', k === p);
    body.innerHTML = ''; build[p]().forEach((n) => body.appendChild(n));
    live();
  }

  CC.settingsScreen = {
    mount(host) {
      root = host; host.classList.add('sub');
      host.appendChild(el('div', 'hdr', '<h1>Configurações</h1>'));
      const grid = el('div', 'cfg'), menu = el('div', 'panel menu'); body = el('div', 'panel body');
      PAGES.forEach(([id, nm]) => { const b = el('button', '', nm); b.addEventListener('click', () => showPage(id)); menu.appendChild(b); menuBtns[id] = b; });
      grid.append(menu, body); host.appendChild(grid);
      CC.bus.on('link', live); CC.bus.on('obdlog', () => { if (timer == null) live(); });
      showPage(page); this.show();
    },
    show() { clearInterval(timer); timer = setInterval(live, 1000); showPage(page); },
    hide() { clearInterval(timer); timer = null; },
  };
})();
