/* Componentes reutilizáveis das telas secundárias (botões grandes, seletor, passo, chave). */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const el = CC.util.el;

  CC.w = {
    btn(text, cls, fn) { const b = el('button', 'btn ' + (cls || ''), text); b.addEventListener('click', fn); return b; },
    /** seletor segmentado: opts = [[valor, rótulo], ...] */
    seg(opts, value, onChange) {
      const d = el('div', 'seg');
      const set = (v) => d.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === String(v)));
      opts.forEach(([v, t]) => {
        const b = el('button', '', t); b.dataset.v = String(v);
        b.addEventListener('click', () => { set(v); onChange(v); });
        d.appendChild(b);
      });
      set(value); d.set = set;
      return d;
    },
    /** passo com − / + ; fmt(v) retorna HTML do valor */
    stepper(o) {
      const d = el('div', 'stepper'), m = el('button', '', '−'), out = el('output'), p = el('button', '', '+');
      let v = o.value;
      const dec = (String(o.step).split('.')[1] || '').length;
      const show = () => { out.innerHTML = o.fmt ? o.fmt(v) : v.toFixed(dec); };
      const bump = (dir) => {
        v = CC.util.clamp(Math.round((v + dir * o.step) * 1000) / 1000, o.min, o.max);
        show(); o.onChange(v);
      };
      m.addEventListener('click', () => bump(-1)); p.addEventListener('click', () => bump(1));
      // pressionar e segurar repete
      [[m, -1], [p, 1]].forEach(([b, dir]) => {
        let t = null, iv = null;
        const stop = () => { clearTimeout(t); clearInterval(iv); };
        b.addEventListener('pointerdown', () => { t = setTimeout(() => { iv = setInterval(() => bump(dir), 90); }, 450); });
        ['pointerup', 'pointerleave', 'pointercancel'].forEach((e) => b.addEventListener(e, stop));
      });
      d.append(m, out, p); show();
      d.setValue = (x) => { v = x; show(); };
      return d;
    },
    toggle(on, onChange) {
      const t = el('button', 'toggle' + (on ? ' on' : ''));
      t.setAttribute('role', 'switch');
      t.addEventListener('click', () => { const n = !t.classList.contains('on'); t.classList.toggle('on', n); onChange(n); });
      return t;
    },
    qtag(q) { return '<span class="q ' + q + '">' + ({ real: 'REAL', calc: 'CALC', est: 'EST', sim: 'SIM', na: 'N/D' }[q] || '') + '</span>'; },
  };
})();
