/* Estrutura geral: escala do palco, navegação, barra superior, banner de alerta, brilho e tema. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const $ = (id) => document.getElementById(id);
  const DAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  const MONTHS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  const DESIGN_H = 941, DESIGN_W = 1672, MAX_W = 2400;
  let current = 'dash';
  const mounted = {};

  /* ---------- escala: cabe em qualquer proporção ---------- */
  function fit() {
    const vw = window.innerWidth, vh = window.innerHeight;
    const aspect = vw / vh;
    const W = Math.round(Math.min(MAX_W, Math.max(DESIGN_W, DESIGN_H * aspect)));
    const s = Math.min(vw / W, vh / DESIGN_H);
    const st = $('stage');
    st.style.width = W + 'px';
    st.style.transform = 'translate(-50%,-50%) scale(' + s.toFixed(5) + ')';
    document.documentElement.style.setProperty('--W', W + 'px');
    const cl = $('topline'); if (cl) cl.style.width = W + 'px';
  }

  /* ---------- navegação ---------- */
  const SCREENS = { trip: 'tripScreen', engine: 'engineScreen', alerts: 'alertsScreen', settings: 'settingsScreen' };
  function go(name) {
    if (!name || name === current && mounted[name] !== undefined) { if (name === current) return; }
    if (SCREENS[name] && !mounted[name]) {
      CC[SCREENS[name]].mount($('screen-' + name));
      mounted[name] = true;
    }
    document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('active', s.id === 'screen-' + name));
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.go === name));
    const prev = current; current = name;
    if (prev !== name) { if (CC[SCREENS[prev]] && CC[SCREENS[prev]].hide) CC[SCREENS[prev]].hide(); if (CC[SCREENS[name]] && CC[SCREENS[name]].show) CC[SCREENS[name]].show(); }
  }

  /* ---------- relógio ---------- */
  function clock() {
    const d = new Date();
    $('clock').textContent = CC.util.pad2(d.getHours()) + ':' + CC.util.pad2(d.getMinutes());
    $('date').textContent = DAYS[d.getDay()] + ', ' + CC.util.pad2(d.getDate()) + ' ' + MONTHS[d.getMonth()];
  }

  /* ---------- tema e brilho ---------- */
  function applyTheme() { document.body.dataset.theme = CC.settings.theme; }
  function applyBrightness() {
    let b = CC.settings.brightness;
    if (CC.settings.brightnessAuto) { const h = new Date().getHours(); if (h >= 18 || h < 6) b = Math.min(b, 55); }
    $('dim').style.opacity = String(Math.max(0, Math.min(0.75, (100 - b) / 100 * 0.95)));
  }

  /* ---------- estado do enlace ---------- */
  function linkUI() {
    const L = CC.link.get(), pill = $('srcPill'), bt = $('btnBt');
    let text, c, b;
    if (L.mode === 'demo') { text = L.state === 'lost' ? 'DEMO · FALHA' : 'DEMO'; c = L.state === 'lost' ? 'err' : 'sim'; b = L.state === 'lost' ? 'err' : ''; }
    else if (L.state === 'ready') { text = 'OBD2'; c = 'real'; b = 'on'; }
    else if (L.state === 'connecting') { text = 'CONECTANDO'; c = 'busy'; b = 'busy'; }
    else if (L.state === 'lost') { text = 'SEM SINAL'; c = 'err'; b = 'err'; }
    else if (L.state === 'error') { text = 'OBD2 · ERRO'; c = 'err'; b = 'err'; }
    else { text = 'OBD2 · OFF'; c = 'err'; b = ''; }
    pill.textContent = text; pill.className = 'pill ' + c;
    bt.className = 'tbicon ' + b;
  }

  /* ---------- banner de alertas ---------- */
  function alertsUI() {
    const act = CC.alerts.active(), ban = $('alertBanner');
    const any = act.length > 0, top = act[0];
    $('btnBell').classList.toggle('alarm', any);
    document.querySelector('.tab[data-go=alerts]').classList.toggle('alarm', any);
    if (!any) { ban.classList.remove('on', 'warn', 'muted'); return; }
    ban.classList.add('on');
    ban.classList.toggle('warn', top.rule.level !== 'crit');
    ban.classList.toggle('muted', !!top.muted);
    $('abTitle').textContent = top.rule.short + (act.length > 1 ? '  (+' + (act.length - 1) + ')' : '');
    $('abText').textContent = top.text;
  }

  CC.shell = {
    go, fit, current: () => current,
    init() {
      fit();
      window.addEventListener('resize', fit);
      window.addEventListener('orientationchange', () => setTimeout(fit, 120));
      document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => go(t.dataset.go)));
      $('btnHome').addEventListener('click', () => go('dash'));
      $('btnBell').addEventListener('click', () => go('alerts'));
      $('btnBt').addEventListener('click', () => go('settings'));
      $('btnBright').addEventListener('click', () => {
        const steps = [100, 70, 45, 30]; const cur = CC.settings.brightness;
        const next = steps.find((s) => s < cur - 1) || 100;
        CC.set('brightnessAuto', false); CC.set('brightness', next);
      });
      $('alertBanner').addEventListener('click', () => { CC.alerts.mute(); });
      // painel: tocar nas bandejas abre telas relacionadas
      document.querySelector('.trayR').addEventListener('click', () => go('engine'));
      document.querySelector('.trayL').addEventListener('click', () => go('trip'));
      document.querySelector('.trayR').style.pointerEvents = 'auto';
      document.querySelector('.trayL').style.pointerEvents = 'auto';
      CC.bus.on('settings', (p) => { if (p === 'theme') applyTheme(); if (p === 'brightness' || p === 'brightnessAuto') applyBrightness(); });
      CC.bus.on('link', linkUI);
      CC.bus.on('alerts', alertsUI);
      applyTheme(); applyBrightness(); linkUI(); clock();
      setInterval(clock, 5000);
      setInterval(applyBrightness, 60000);
      // impede menu de contexto / arrastar / zoom de gesto
      document.addEventListener('contextmenu', (e) => e.preventDefault());
      document.addEventListener('gesturestart', (e) => e.preventDefault());
    },
  };
})();
