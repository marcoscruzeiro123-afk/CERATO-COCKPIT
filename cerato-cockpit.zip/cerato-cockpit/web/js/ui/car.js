/* Ilustração central: sedã prata (Cerato EX3 2012) visto de frente — desenho vetorial original,
 * com a assinatura do modelo (grade trapezoidal, faróis alongados, neblina baixa) + estrada com brilho. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});

  function carSVG() {
    const L = [], A = (x) => L.push(x);
    A('<svg viewBox="0 0 300 206" xmlns="http://www.w3.org/2000/svg"><defs>');
    A('<linearGradient id="cb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6f9fd"/><stop offset=".4" stop-color="#bcc7d9"/><stop offset=".8" stop-color="#7f8da7"/><stop offset="1" stop-color="#4a566e"/></linearGradient>');
    A('<linearGradient id="chd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".5" stop-color="#cdd7e8"/><stop offset="1" stop-color="#8e9cb6"/></linearGradient>');
    A('<linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#27344d"/><stop offset=".6" stop-color="#0b1222"/><stop offset="1" stop-color="#05080f"/></linearGradient>');
    A('<linearGradient id="cr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e4ebf7"/><stop offset="1" stop-color="#8a98b2"/></linearGradient>');
    A('<radialGradient id="hl" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff"/><stop offset=".4" stop-color="#d4e9ff"/><stop offset="1" stop-color="#2a5ab0" stop-opacity="0"/></radialGradient>');
    A('<linearGradient id="crm" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff"/><stop offset=".5" stop-color="#9fb0cb"/><stop offset="1" stop-color="#e8eefa"/></linearGradient>');
    A('<filter id="gl"><feGaussianBlur stdDeviation="3.5"/></filter></defs>');
    /* pneus */
    A('<rect x="20" y="162" width="32" height="36" rx="7" fill="#05070b"/><rect x="248" y="162" width="32" height="36" rx="7" fill="#05070b"/>');
    /* teto, para-brisa e colunas (cabine baixa e alongada do sedã) */
    A('<path d="M88 50 Q150 34 212 50 L222 60 Q150 46 78 60Z" fill="url(#cr)"/>');
    A('<path d="M72 62 Q150 46 228 62 L250 102 L50 102Z" fill="url(#cg)"/>');
    A('<path d="M80 64 Q118 54 148 53 L134 102 L56 102Z" fill="#fff" opacity=".08"/>');
    A('<path d="M72 62 L50 102 M228 62 L250 102" stroke="#c9d3e5" stroke-width="3" stroke-linecap="round"/>');
    A('<path d="M120 78 Q150 72 180 78 L184 90 Q150 84 116 90Z" fill="#0d1830" opacity=".9"/>');
    /* retrovisores */
    A('<path d="M48 94 L32 95 Q26 100 33 105 L50 103Z" fill="url(#cb)"/><path d="M252 94 L268 95 Q274 100 267 105 L250 103Z" fill="url(#cb)"/>');
    /* capô com vincos laterais */
    A('<path d="M28 104 Q150 86 272 104 L284 130 Q150 116 16 130Z" fill="url(#cb)"/>');
    A('<path d="M58 109 Q150 96 242 109 L236 115 Q150 104 64 115Z" fill="#fff" opacity=".6"/>');
    A('<path d="M104 100 Q116 112 120 126 M196 100 Q184 112 180 126" stroke="#566179" stroke-width="1.3" fill="none" opacity=".7"/>');
    A('<path d="M150 92 L150 122" stroke="#5a667e" stroke-width=".8" opacity=".35"/>');
    /* para-choque inferior */
    A('<path d="M14 132 Q150 152 286 132 L282 178 Q150 194 18 178Z" fill="url(#cb)"/>');
    /* faróis alongados, varridos para trás */
    A('<path d="M16 124 Q22 112 52 110 Q86 108 112 118 L108 136 Q62 143 26 138 Q14 134 16 124Z" fill="#0a111f" stroke="#a8b8d4" stroke-width="1.5"/>');
    A('<path d="M284 124 Q278 112 248 110 Q214 108 188 118 L192 136 Q238 143 274 138 Q286 134 284 124Z" fill="#0a111f" stroke="#a8b8d4" stroke-width="1.5"/>');
    A('<ellipse cx="46" cy="126" rx="15" ry="8" fill="#dbeaff" opacity=".35"/><ellipse cx="82" cy="125" rx="13" ry="7" fill="#dbeaff" opacity=".35"/>');
    A('<ellipse cx="254" cy="126" rx="15" ry="8" fill="#dbeaff" opacity=".35"/><ellipse cx="218" cy="125" rx="13" ry="7" fill="#dbeaff" opacity=".35"/>');
    A('<circle cx="46" cy="126" r="7" fill="url(#hl)"/><circle cx="82" cy="125" r="6" fill="url(#hl)"/><circle cx="254" cy="126" r="7" fill="url(#hl)"/><circle cx="218" cy="125" r="6" fill="url(#hl)"/>');
    A('<path d="M22 118 Q56 109 106 119 M278 118 Q244 109 194 119" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round"/>');
    A('<circle cx="48" cy="127" r="10" fill="#e6f2ff" opacity=".8" filter="url(#gl)"/><circle cx="252" cy="127" r="10" fill="#e6f2ff" opacity=".8" filter="url(#gl)"/>');
    /* grade trapezoidal cromada (assinatura frontal) com colmeia horizontal */
    A('<path d="M110 118 L190 118 L186 146 Q150 154 114 146Z" fill="#06090f" stroke="url(#crm)" stroke-width="3.2" stroke-linejoin="round"/>');
    A('<path d="M118 126 L182 126 M117 132 L183 132 M118 138 L182 138" stroke="#5b6882" stroke-width="1.6" opacity=".9"/>');
    A('<ellipse cx="150" cy="119" rx="13" ry="4.6" fill="#0a0f19" stroke="url(#crm)" stroke-width="1.6"/>');
    /* entrada de ar inferior + faróis de neblina */
    A('<path d="M70 158 Q150 174 230 158 L224 177 Q150 188 76 177Z" fill="#05080e"/>');
    A('<path d="M72 160 Q150 175 228 160" stroke="url(#crm)" stroke-width="1.6" fill="none" opacity=".85"/>');
    A('<path d="M92 168 L208 168 M96 173 L204 173" stroke="#222c40" stroke-width="1.4"/>');
    A('<ellipse cx="40" cy="162" rx="16" ry="7" fill="#06090f" stroke="#a5b4cf" stroke-width="1.4"/><ellipse cx="260" cy="162" rx="16" ry="7" fill="#06090f" stroke="#a5b4cf" stroke-width="1.4"/>');
    A('<ellipse cx="40" cy="162" rx="7" ry="3" fill="#d9ecff" opacity=".85"/><ellipse cx="260" cy="162" rx="7" ry="3" fill="#d9ecff" opacity=".85"/>');
    A('<path d="M20 150 Q34 144 56 148 M280 150 Q266 144 244 148" stroke="#fff" stroke-width="1.2" fill="none" opacity=".55"/>');
    /* placa */
    A('<rect x="124" y="164" width="52" height="13" rx="2.5" fill="#eef1f7" stroke="#6c7890" stroke-width="1"/>');
    A('<text x="150" y="174.4" text-anchor="middle" font-size="8.2" font-weight="700" fill="#243049" font-family="Roboto,Arial,sans-serif" letter-spacing="1.2">CERATO</text>');
    A('</svg>');
    return L.join('');
  }

  function roadSVG() {
    return '<svg viewBox="0 0 640 230" width="640" height="230" xmlns="http://www.w3.org/2000/svg">'
      + '<defs><radialGradient id="rg" cx=".5" cy=".42" r=".55"><stop offset="0" stop-color="#3a84ff" stop-opacity=".55"/><stop offset=".55" stop-color="#1a4fc0" stop-opacity=".22"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>'
      + '<linearGradient id="rl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6fb4ff" stop-opacity="0"/><stop offset="1" stop-color="#9fd0ff" stop-opacity=".75"/></linearGradient></defs>'
      + '<ellipse cx="320" cy="120" rx="310" ry="104" fill="url(#rg)"/>'
      + '<path d="M300 18 L220 230 M340 18 L420 230 M320 20 L320 230" stroke="url(#rl)" stroke-width="2" fill="none" opacity=".7"/>'
      + '<path d="M312 40 L308 70 M328 40 L332 70 M306 96 L298 150 M334 96 L342 150" stroke="#a9d3ff" stroke-width="3" opacity=".5" stroke-linecap="round"/>'
      + '<ellipse cx="320" cy="200" rx="180" ry="16" fill="#000" opacity=".55"/>'
      + '</svg>';
  }

  CC.car = {
    mount() {
      const w = document.getElementById('carwrap');
      const img = new Image(); img.alt = ''; img.src = 'assets/cerato.png';
      img.onerror = () => { w.innerHTML = carSVG(); };   // reserva: desenho vetorial
      w.appendChild(img);
      document.getElementById('roadglow').innerHTML = roadSVG();
    },
  };
})();
