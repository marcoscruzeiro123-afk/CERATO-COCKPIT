/* Mostradores em SVG: faces analógicas, ponteiros com suavização, arcos segmentados e mini-arcos.
 * Faces são desenhadas uma vez (estáticas); só o ponteiro se move, em camada própria (GPU). */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const rad = (d) => (d * Math.PI) / 180;
  const pt = (cx, cy, r, deg) => [cx + r * Math.sin(rad(deg)), cy - r * Math.cos(rad(deg))];
  const f1 = (n) => n.toFixed(2);
  function arcPath(cx, cy, r, a0, a1) {
    const [x0, y0] = pt(cx, cy, r, a0), [x1, y1] = pt(cx, cy, r, a1);
    return 'M' + f1(x0) + ',' + f1(y0) + ' A' + r + ',' + r + ' 0 ' + (Math.abs(a1 - a0) > 180 ? 1 : 0) + ' ' + (a1 >= a0 ? 1 : 0) + ' ' + f1(x1) + ',' + f1(y1);
  }

  const A0 = -120, A1 = 120; // varredura de 240°

  /* ---------- face do mostrador (600×600, centro 300,300) ---------- */
  function dialFace(o) {
    const id = o.id, ang = (v) => A0 + ((v - o.min) / (o.max - o.min)) * (A1 - A0);
    let s = '<svg viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">';
    s += '<defs>'
      + '<linearGradient id="' + id + 'sv" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".28" stop-color="#9aa8c2"/><stop offset=".55" stop-color="#1c2538"/><stop offset=".8" stop-color="#7e8ca8"/><stop offset="1" stop-color="#e8eefb"/></linearGradient>'
      + '<radialGradient id="' + id + 'fc" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#010308"/><stop offset=".5" stop-color="#02060f"/><stop offset=".8" style="stop-color:var(--face1)"/><stop offset="1" stop-color="#02050c"/></radialGradient>'
      + '<radialGradient id="' + id + 'hb" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#000"/><stop offset=".92" stop-color="#01040a"/><stop offset="1" stop-color="#0a1a3c"/></radialGradient>'
      + '<filter id="' + id + 'bl" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="7"/></filter>'
      + '<linearGradient id="' + id + 'rd" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff5a3c"/><stop offset="1" stop-color="#e0001a"/></linearGradient>'
      + '</defs>';
    s += '<circle class="glowring" cx="300" cy="300" r="286" filter="url(#' + id + 'bl)"/>';
    s += '<circle cx="300" cy="300" r="284" fill="none" style="stroke:var(--accent2)" stroke-width="2" opacity=".85"/>';
    s += '<circle cx="300" cy="300" r="272" fill="url(#' + id + 'fc)" stroke="url(#' + id + 'sv)" stroke-width="8"/>';
    s += '<circle cx="300" cy="300" r="264" fill="none" stroke="rgba(150,190,255,.16)" stroke-width="1.5"/>';

    const redFrom = o.redFrom != null ? o.redFrom : o.max;
    // arco da escala
    s += '<path d="' + arcPath(300, 300, 252, A0, ang(redFrom)) + '" fill="none" style="stroke:var(--accent);filter:drop-shadow(0 0 5px var(--accent))" stroke-width="3.4" opacity=".9"/>';
    if (redFrom < o.max) {
      s += '<path d="' + arcPath(300, 300, 252, ang(redFrom), A1) + '" fill="none" stroke="url(#' + id + 'rd)" stroke-width="22" opacity=".95" style="filter:drop-shadow(0 0 6px rgba(255,20,40,.7))"/>';
      s += '<path d="' + arcPath(300, 300, 237, ang(redFrom), A1) + '" fill="none" stroke="rgba(255,90,90,.9)" stroke-width="1.6"/>';
    }
    // marcas e rótulos
    const eps = 1e-6, ro = 242;
    for (let v = o.min; v <= o.max + eps; v += o.fine) {
      const isMaj = Math.abs(v / o.major - Math.round(v / o.major)) < eps;
      const isMid = !isMaj && o.mid && Math.abs(v / o.mid - Math.round(v / o.mid)) < eps;
      const len = isMaj ? 30 : isMid ? 20 : 11, w = isMaj ? 4.2 : isMid ? 2.8 : 1.5;
      const a = ang(v), [x0, y0] = pt(300, 300, ro, a), [x1, y1] = pt(300, 300, ro - len, a);
      const red = v >= redFrom - eps;
      s += '<line x1="' + f1(x0) + '" y1="' + f1(y0) + '" x2="' + f1(x1) + '" y2="' + f1(y1) + '" stroke="' + (red ? '#ff6a6a' : '#f2f7ff') + '" stroke-width="' + w + '" stroke-linecap="butt" opacity="' + (isMaj ? 1 : isMid ? 0.85 : 0.6) + '"/>';
      if (isMaj) {
        const [tx, ty] = pt(300, 300, o.labelR, a);
        s += '<text x="' + f1(tx) + '" y="' + f1(ty) + '" text-anchor="middle" dominant-baseline="central" fill="#eef4ff" font-size="' + o.fs + '" font-weight="600" font-style="italic" font-family="Roboto,Segoe UI,Arial,sans-serif">' + o.label(v) + '</text>';
      }
    }
    // disco central
    s += '<circle cx="300" cy="300" r="138" fill="url(#' + id + 'hb)" stroke="rgba(130,170,255,.28)" stroke-width="1.6"/>';
    s += '<circle cx="300" cy="300" r="146" fill="none" stroke="rgba(100,150,255,.12)" stroke-width="1"/>';
    return s + '</svg>';
  }

  function needleSVG(id, r0, r1) {
    const y0 = 300 - r0, y1 = 300 - r1;
    return '<svg viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="' + id + 'ng" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ff9a8a"/><stop offset=".35" stop-color="#ff2a3a"/><stop offset="1" stop-color="#ff1a30" stop-opacity=".95"/></linearGradient></defs>'
      + '<path d="M296.3 ' + y0 + ' L303.7 ' + y0 + ' L300.9 ' + y1 + ' L299.1 ' + y1 + ' Z" fill="url(#' + id + 'ng)"/>'
      + '<path d="M298.4 ' + y0 + ' L301.6 ' + y0 + ' L300.3 ' + (y0 - 70) + ' L299.7 ' + (y0 - 70) + ' Z" fill="#ffd0c8" opacity=".55"/></svg>';
  }

  /* ---------- ponteiro com suavização exponencial ---------- */
  class Needle {
    constructor(el, o) {
      this.el = el; this.min = o.min; this.max = o.max; this.k = o.k || 7;
      this.cur = o.min; this.target = o.min; this.lastA = null;
      this.apply(true);
    }
    set(v) { if (v == null || !isFinite(v)) v = this.min; this.target = Math.min(this.max, Math.max(this.min, v)); }
    angle(v) { return A0 + ((v - this.min) / (this.max - this.min)) * (A1 - A0); }
    step(dt) {
      this.cur += (this.target - this.cur) * (1 - Math.exp(-this.k * dt));
      this.apply(false);
    }
    apply(force) {
      const a = this.angle(this.cur);
      if (force || this.lastA === null || Math.abs(a - this.lastA) > 0.03) {
        this.lastA = a;
        this.el.style.transform = 'rotate(' + a.toFixed(2) + 'deg)';
      }
    }
  }
  const needles = [];
  let lastT = 0, raf = 0;
  function loop(t) {
    const dt = lastT ? Math.min(0.06, (t - lastT) / 1000) : 0.016;
    lastT = t;
    for (const n of needles) n.step(dt);
    raf = requestAnimationFrame(loop);
  }
  function startLoop() { if (!raf && typeof requestAnimationFrame !== 'undefined') raf = requestAnimationFrame(loop); }

  /* ---------- arco segmentado (bandejas inferiores) ---------- */
  function segArc(g, o) {
    const NS = 'http://www.w3.org/2000/svg';
    const segs = [], seg = (o.a1 - o.a0) / o.n, gap = seg * 0.14;
    // trilho e marcas
    const rail = document.createElementNS(NS, 'path');
    rail.setAttribute('d', arcPath(o.cx, o.cy, o.r - 20, o.a0, o.a1));
    rail.setAttribute('fill', 'none'); rail.setAttribute('stroke', 'rgba(170,200,255,.25)'); rail.setAttribute('stroke-width', '1.5');
    g.appendChild(rail);
    for (let i = 0; i <= o.n; i++) {
      const a = o.a0 + i * seg, [x0, y0] = pt(o.cx, o.cy, o.r - 12, a), [x1, y1] = pt(o.cx, o.cy, o.r - 28, a);
      const l = document.createElementNS(NS, 'line');
      l.setAttribute('x1', f1(x0)); l.setAttribute('y1', f1(y0)); l.setAttribute('x2', f1(x1)); l.setAttribute('y2', f1(y1));
      l.setAttribute('stroke', 'rgba(210,225,255,.55)'); l.setAttribute('stroke-width', i % 2 ? '1.2' : '2');
      g.appendChild(l);
    }
    for (let i = 0; i < o.n; i++) {
      const p = document.createElementNS(NS, 'path');
      p.setAttribute('d', arcPath(o.cx, o.cy, o.r, o.a0 + i * seg + gap / 2, o.a0 + (i + 1) * seg - gap / 2));
      p.setAttribute('fill', 'none'); p.setAttribute('stroke-width', o.width || 13);
      p.style.stroke = o.color(i, o.n); p.style.transition = 'opacity .35s';
      p.style.opacity = 0.16;
      g.appendChild(p); segs.push(p);
    }
    let last = -1;
    return {
      set(frac, colorOverride) {
        const lit = frac == null ? -1 : Math.round(Math.min(1, Math.max(0, frac)) * o.n);
        const key = lit + '|' + (colorOverride || '');
        if (key === last) return; last = key;
        segs.forEach((p, i) => {
          const on = i < lit;
          p.style.opacity = on ? 1 : 0.16;
          p.style.filter = on ? 'drop-shadow(0 0 5px ' + (colorOverride || p.style.stroke) + ')' : 'none';
        });
      },
    };
  }

  /* ---------- mini-arco (tela Motor) ---------- */
  function arcGauge(host, o) {
    const NS = 'http://www.w3.org/2000/svg', S = o.size || 210, c = S / 2, r = (o.r || S * 0.42);
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 ' + S + ' ' + S);
    const track = document.createElementNS(NS, 'path'), val = document.createElementNS(NS, 'path');
    const d = arcPath(c, c, r, A0, A1);
    track.setAttribute('d', d); val.setAttribute('d', d);
    track.setAttribute('pathLength', '100'); val.setAttribute('pathLength', '100');
    for (const p of [track, val]) { p.setAttribute('fill', 'none'); p.setAttribute('stroke-linecap', 'round'); p.setAttribute('stroke-width', o.w || 16); }
    track.setAttribute('stroke', 'rgba(255,255,255,.12)');
    val.setAttribute('stroke-dasharray', '0 100'); val.style.transition = 'stroke-dasharray .45s linear, stroke .3s';
    svg.appendChild(track);
    // zonas coloridas finas por fora
    (o.zones || []).forEach((z) => {
      const a = A0 + ((z.from - o.min) / (o.max - o.min)) * (A1 - A0), b = A0 + ((z.to - o.min) / (o.max - o.min)) * (A1 - A0);
      const zp = document.createElementNS(NS, 'path');
      zp.setAttribute('d', arcPath(c, c, r + (o.w || 16) / 2 + 6, a, b)); zp.setAttribute('fill', 'none');
      zp.setAttribute('stroke', z.color); zp.setAttribute('stroke-width', '4'); zp.setAttribute('opacity', '.8');
      svg.appendChild(zp);
    });
    svg.appendChild(val);
    host.appendChild(svg);
    let lastKey = '';
    return {
      set(v) {
        if (v == null || !isFinite(v)) { if (lastKey !== 'na') { val.setAttribute('stroke-dasharray', '0 100'); lastKey = 'na'; } return; }
        const f = Math.min(1, Math.max(0, (v - o.min) / (o.max - o.min)));
        let col = o.color || 'var(--accent2)';
        (o.zones || []).forEach((z) => { if (v >= z.from && v <= z.to) col = z.color; });
        const key = (f * 100).toFixed(1) + col;
        if (key === lastKey) return; lastKey = key;
        val.setAttribute('stroke-dasharray', (f * 100).toFixed(2) + ' 100'); val.style.stroke = col;
      },
    };
  }

  CC.gauges = {
    A0, A1, arcPath, pt, dialFace, needleSVG, Needle, segArc, arcGauge,
    addNeedle(n) { needles.push(n); startLoop(); return n; },
    start: startLoop,
  };
})();
