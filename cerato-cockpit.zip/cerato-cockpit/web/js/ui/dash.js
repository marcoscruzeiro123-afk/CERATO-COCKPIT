/* Painel principal: monta os mostradores e atualiza os textos (~8 Hz). Ponteiros animam a 60 fps em gauges.js. */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const $ = (id) => document.getElementById(id);
  const U = () => CC.units;
  const G = () => CC.gauges;

  let tach, speed, fuelArc, tempArc, speedUnitKey = '';

  /* cache de texto: só mexe no DOM quando muda */
  const cache = {};
  function txt(id, s) { if (cache[id] !== s) { cache[id] = s; $(id).textContent = s; } }
  function cls(id, c) { if (cache['c' + id] !== c) { cache['c' + id] = c; $(id).className = c; } }
  function tag(id, q) {
    const t = q === 'sim' ? 'SIM' : q === 'est' ? 'EST' : q === 'na' ? '' : '';
    txt(id, t);
    cls(id, 'tag' + (t ? ' ' + (q === 'sim' ? 'sim' : 'est') : ''));
  }

  function buildSpeedDial() {
    const mph = CC.get('units.speed') === 'mph', max = mph ? 160 : 240;
    const key = mph ? 'mph' : 'kmh';
    if (key === speedUnitKey) return; speedUnitKey = key;
    $('speedFace').innerHTML = G().dialFace({ id: 'sp', min: 0, max, major: 20, mid: 10, fine: 5, labelR: 196, fs: 28, label: (v) => v });
    $('speedNeedle').innerHTML = G().needleSVG('sp', 96, 238);
    if (!speed) {
      speed = G().addNeedle(new (G().Needle)($('speedNeedle'), { min: 0, max, k: 6.5 }));
    } else { speed.max = max; speed.min = 0; }
    $('speedNeedle').style.transform = 'rotate(-120deg)';
    if (speed) { speed.cur = 0; speed.lastA = null; }
  }

  function build() {
    $('tachFace').innerHTML = G().dialFace({ id: 'tc', min: 0, max: 8, major: 1, mid: 0.5, fine: 0.25, labelR: 194, fs: 31, redFrom: 6.5, label: (v) => v });
    $('tachNeedle').innerHTML = G().needleSVG('tc', 96, 238);
    tach = G().addNeedle(new (G().Needle)($('tachNeedle'), { min: 0, max: 8, k: 9 }));
    buildSpeedDial();

    const cyan = (i, n) => { const t = i / (n - 1); return 'hsl(' + (196 + t * 22) + ',100%,' + (62 - t * 14) + '%)'; };
    const temp = (i, n) => { const t = i / (n - 1); return t > 0.78 ? 'hsl(' + (4 - (t - 0.78) * 20) + ',100%,55%)' : 'hsl(' + (194 + t * 26) + ',100%,' + (62 - t * 16) + '%)'; };
    fuelArc = G().segArc($('fuelArc'), { cx: 290, cy: 425, r: 395, a0: -23, a1: 23, n: 12, width: 14, color: cyan });
    tempArc = G().segArc($('tempArc'), { cx: 290, cy: 425, r: 395, a0: -23, a1: 23, n: 12, width: 14, color: temp });
  }

  const FUEL_COL = (pct) => (pct < 10 ? 'var(--crit)' : pct < 18 ? 'var(--warn)' : null);

  function update() {
    const D = CC.data, u = U();
    /* rotação */
    const rpm = D.val('rpm');
    tach.set(rpm == null ? 0 : rpm / 1000);
    txt('tachDig', rpm == null ? '--' : (rpm / 1000).toFixed(1));
    $('tachDig').style.opacity = rpm == null ? 0.35 : 1;

    /* velocidade */
    buildSpeedDial();
    const sp = D.val('speed');
    const spc = sp == null ? null : u.speed(sp);
    speed.set(spc == null ? 0 : spc);
    txt('speedDig', spc == null ? '--' : String(Math.round(spc)));
    $('speedDig').style.opacity = sp == null ? 0.35 : 1;
    txt('speedUnitTop', u.speedUnit()); txt('speedUnitBot', u.speedUnit());

    /* temperatura do motor */
    const t = D.val('coolant'), tc = t == null ? null : u.temp(t);
    const hot = t != null && t >= CC.settings.alerts.coolantWarn.v, crit = t != null && t >= CC.settings.alerts.coolantCrit.v;
    txt('cTemp', tc == null ? '--' : String(Math.round(tc))); txt('cTempU', u.tempUnit());
    txt('trayTemp', tc == null ? '--' : String(Math.round(tc))); txt('trayTempU', u.tempUnit());
    tag('tagTemp', D.quality('coolant'));
    const frac = t == null ? null : (t - 50) / (120 - 50); // C=50 °C … H=120 °C
    tempArc.set(frac);
    $('cTempBar').style.width = (t == null ? 0 : Math.max(4, Math.min(100, ((t - 40) / 80) * 100))) + '%';
    cls('cTempBar', 'fill' + (crit || hot ? ' hot' : t != null && t < 60 ? ' cold' : ''));
    document.querySelector('.trayR').classList.toggle('alarm-glow', !!crit);
    document.querySelector('.trayR').classList.toggle('warn-glow', !!hot && !crit);

    /* bateria */
    const v = D.val('voltage');
    txt('cVolt', v == null ? '--' : v.toFixed(1)); tag('tagVolt', D.quality('voltage'));
    $('cVoltBar').style.width = (v == null ? 0 : Math.max(4, Math.min(100, ((v - 10) / 5) * 100))) + '%';

    /* consumo e autonomia */
    const avg = D.val('avgCons'), ac = avg == null ? null : u.cons(avg);
    txt('cAvg', ac == null ? '--' : ac.toFixed(1)); txt('cAvgU', u.consUnit()); tag('tagAvg', D.quality('avgCons'));
    const ic = D.val('instCons');
    const rate = D.val('fuelRate');
    if (ic != null) { txt('cInst', u.cons(ic).toFixed(1)); txt('cInstU', u.consUnit()); }
    else if (rate != null && (D.val('speed') || 0) < 5) { txt('cInst', rate.toFixed(1)); txt('cInstU', 'L/h'); }
    else { txt('cInst', '--'); txt('cInstU', u.consUnit()); }
    tag('tagInst', D.quality(ic != null ? 'instCons' : 'fuelRate'));
    const rg = D.val('range');
    txt('cRange', rg == null ? '--' : String(Math.round(u.dist(rg)))); txt('cRangeU', u.distUnit()); tag('tagRange', D.quality('range'));

    /* combustível (bandeja esquerda) */
    const pct = D.val('fuelPct'), fl = D.val('fuelL');
    fuelArc.set(pct == null ? null : pct / 100, FUEL_COL(pct == null ? 100 : pct));
    txt('fuelVal', fl == null ? '--' : fl.toFixed(1)); txt('fuelUnit', 'L');
    txt('fuelPct', pct == null ? 'nível indisponível' : Math.round(pct) + ' %' + (D.quality('fuelPct') === 'est' ? ' · estimado' : D.quality('fuelPct') === 'sim' ? ' · simulado' : ''));

    /* marcha e ar de admissão */
    const g = D.val('gear');
    txt('gearVal', g == null ? '--' : g + 'ª'); tag('tagGear', D.quality('gear'));
    const ia = D.val('iat');
    txt('iatVal', ia == null ? '--' : String(Math.round(u.temp(ia)))); txt('iatU', u.tempUnit()); tag('tagIat', D.quality('iat'));
  }

  CC.dash = {
    init() {
      build();
      CC.car.mount();
      setInterval(update, 120);
      CC.bus.on('settings', (p) => { if (p.indexOf('units') === 0) update(); });
      update();
    },
  };
})();
