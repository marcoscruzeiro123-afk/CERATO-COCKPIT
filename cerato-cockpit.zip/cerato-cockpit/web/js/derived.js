/* Grandezas derivadas: vazão de combustível, consumo instantâneo, marcha estimada,
 * combustível restante e autonomia. Nada aqui inventa dado: se faltar entrada, o resultado é "na". */
(function () {
  'use strict';
  const CC = (globalThis.CC = globalThis.CC || {});
  const { clamp } = CC.util;

  /** pior qualidade entre as entradas (sim > est > calc > real) */
  function worst(keys) {
    const rank = { real: 0, calc: 1, est: 2, sim: 3 };
    let w = 'real';
    for (const k of keys) {
      const q = CC.data.quality(k);
      if (q === 'na') return null;
      if (rank[q] > rank[w]) w = q;
    }
    return w;
  }
  const down = (q, floor) => { const r = { real: 0, calc: 1, est: 2, sim: 3 }; return r[q] >= r[floor] ? q : floor; };

  /* ---------- modelo manual de combustível (quando a ECU não informa o nível) ---------- */
  const fuelModel = { liters: null };
  CC.fuelModel = {
    get: () => fuelModel.liters,
    setFull() { fuelModel.liters = CC.get('vehicle.tankL'); persist(); },
    set(l) { fuelModel.liters = l; persist(); },
    load(profile) {
      const s = CC.store.read('cerato.fuelmodel.' + profile, null);
      fuelModel.liters = s && typeof s.liters === 'number' ? s.liters : null;
    },
    profile: 'demo',
  };
  function persist() { CC.store.write('cerato.fuelmodel.' + CC.fuelModel.profile, { liters: fuelModel.liters }); }

  /* ---------- marcha estimada ---------- */
  let gearCand = null, gearCount = 0, gearOut = null;
  function gearK() {
    const g = CC.GEARS, tire = CC.get('vehicle.tire') || 1.99;
    return g.ratios.map((r) => (r * g.finalDrive * 1000) / (60 * tire)); // rpm por km/h
  }
  CC.gearK = gearK;

  function estimateGear(rpm, speed) {
    if (rpm == null || speed == null || speed < 8 || rpm < 700) return null;
    const ratio = rpm / speed, ks = gearK();
    let best = -1, bestErr = 1;
    ks.forEach((k, i) => { const e = Math.abs(ratio - k) / k; if (e < bestErr) { bestErr = e; best = i; } });
    return bestErr < 0.09 ? best + 1 : null;
  }

  /* ---------- cálculo principal (chamado ~10 Hz) ---------- */
  let lastT = 0;
  CC.derivedUpdate = function () {
    const now = CC.util.now();
    const dt = lastT ? Math.min(2, (now - lastT) / 1000) : 0;
    lastT = now;

    const speed = CC.data.val('speed'), rpm = CC.data.val('rpm');
    const veh = CC.settings.vehicle, fuelT = CC.FUELS[veh.fuel] || CC.FUELS.flex_gas;

    /* vazão de combustível (L/h) */
    let rate = null, rq = null;
    const maf = CC.data.val('maf');
    if (maf != null) {
      const gps = maf / fuelT.afr;
      rate = (gps * 3600) / fuelT.dens;
      rq = down(worst(['maf']) || 'real', 'calc');
    } else {
      const map = CC.data.val('map'), iat = CC.data.val('iat');
      if (map != null && iat != null && rpm != null) {
        const vd = veh.dispCc / 1e6;
        const airKgS = (veh.ve / 100) * (map * 1000) * vd * (rpm / 120) / (287 * (iat + 273.15));
        rate = (airKgS * 1000 / fuelT.afr * 3600) / fuelT.dens;
        rq = down(worst(['map', 'iat', 'rpm']) || 'real', 'est');
      }
    }
    if (rate != null && (rpm != null && rpm < 100)) rate = 0;
    if (rate == null) CC.data.setNA('fuelRate', 'sem MAF/MAP');
    else CC.data.set('fuelRate', rate, rq);

    /* consumo instantâneo (km/L) — só em movimento */
    if (rate != null && speed != null && speed >= 5 && rate > 0.05) {
      CC.data.set('instCons', clamp(speed / rate, 0, 99), rq);
    } else CC.data.setNA('instCons', 'parado');

    /* marcha */
    if (veh.gearEst) {
      const g = estimateGear(rpm, speed);
      if (g === gearCand) gearCount++; else { gearCand = g; gearCount = 1; }
      if (gearCount >= 3) gearOut = gearCand;
      if (gearOut != null) CC.data.set('gear', gearOut, worst(['rpm', 'speed']) === 'sim' ? 'sim' : 'est');
      else CC.data.setNA('gear', 'indefinida');
    } else CC.data.setNA('gear', 'desativada');

    /* combustível restante */
    const tank = veh.tankL;
    const lvl = CC.data.val('fuel');
    if (lvl != null) {
      CC.data.set('fuelPct', lvl, CC.data.quality('fuel'));
      CC.data.set('fuelL', (lvl / 100) * tank, down(CC.data.quality('fuel'), 'calc'));
    } else if (fuelModel.liters != null) {
      if (rate != null && dt > 0) { fuelModel.liters = Math.max(0, fuelModel.liters - (rate * dt) / 3600); }
      const q = rq === 'sim' ? 'sim' : 'est';
      CC.data.set('fuelL', fuelModel.liters, q);
      CC.data.set('fuelPct', (fuelModel.liters / tank) * 100, q);
    } else { CC.data.setNA('fuelL', 'nível não informado'); CC.data.setNA('fuelPct', 'nível não informado'); }

    /* consumo médio e autonomia (viagem A) */
    const trip = CC.trip && CC.trip.get('A');
    const avg = trip ? trip.avgCons() : null;
    if (avg != null) CC.data.set('avgCons', avg, rq === 'sim' ? 'sim' : (rq === 'est' ? 'est' : 'calc'));
    else CC.data.setNA('avgCons', 'sem dados');

    const fl = CC.data.get('fuelL');
    if (avg != null && fl && fl.q !== 'na') {
      const q = [fl.q, CC.data.quality('avgCons')].includes('sim') ? 'sim' : ([fl.q, CC.data.quality('avgCons')].includes('est') ? 'est' : 'calc');
      CC.data.set('range', Math.max(0, fl.v * avg), q);
    } else CC.data.setNA('range', 'sem dados');

    /* integra viagem */
    if (CC.trip) CC.trip.integrate(dt, speed, rate);
  };
})();
