package br.cerato.cockpit

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Ponte JS ↔ Bluetooth clássico (SPP/RFCOMM). Contrato descrito em web/js/sources/transport-bridge.js */
@SuppressLint("MissingPermission")
class BtBridge(private val act: Activity, private val web: WebView) {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var sock: BluetoothSocket? = null
    @Volatile private var gen = 0

    private fun ensurePerm() {
        if (Build.VERSION.SDK_INT >= 31 && act.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            act.requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
    }
    private fun js(code: String) = act.runOnUiThread { web.evaluateJavascript(code, null) }
    private fun q(s: String) = JSONObject.quote(s)

    @JavascriptInterface fun listPairedDevices(): String {
        ensurePerm()
        val arr = JSONArray()
        BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.forEach {
            arr.put(JSONObject().put("name", it.name ?: "?").put("address", it.address))
        }
        return arr.toString()
    }

    @JavascriptInterface fun connect(address: String) {
        disconnect(); val my = ++gen; ensurePerm()
        Thread {
            try {
                val ad = BluetoothAdapter.getDefaultAdapter() ?: throw Exception("Bluetooth indisponível")
                ad.cancelDiscovery()
                val dev = ad.getRemoteDevice(address)
                var s: BluetoothSocket
                try { s = dev.createRfcommSocketToServiceRecord(spp); s.connect() }
                catch (e: Exception) { // alternativa comum para clones ELM327
                    s = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType).invoke(dev, 1) as BluetoothSocket; s.connect()
                }
                if (my != gen) { s.close(); return@Thread }
                sock = s
                js("CCNative.onState('connected','')")
                val inp = s.inputStream; val buf = ByteArray(512)
                while (my == gen) {
                    val n = inp.read(buf); if (n < 0) break
                    js("CCNative.onData(" + q(String(buf, 0, n, Charsets.ISO_8859_1)) + ")")
                }
                if (my == gen) js("CCNative.onState('closed','conexão encerrada')")
            } catch (e: Exception) {
                if (my == gen) js("CCNative.onState('error'," + q(e.message ?: "falha ao conectar") + ")")
            }
        }.start()
    }

    @JavascriptInterface fun write(text: String) {
        try { sock?.outputStream?.apply { write(text.toByteArray(Charsets.ISO_8859_1)); flush() } } catch (e: Exception) { /* leitura detecta a queda */ }
    }

    @JavascriptInterface fun disconnect() { gen++; try { sock?.close() } catch (e: Exception) {}; sock = null }
}
