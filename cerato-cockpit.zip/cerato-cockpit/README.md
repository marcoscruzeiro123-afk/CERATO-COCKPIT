# Cerato Digital Cockpit

Computador de bordo digital para Kia Cerato EX3 1.6 AT 2012 (multimídia Aikon Proton, Android 10, tela horizontal).
HTML5 + CSS3 + JavaScript puro + SVG, sem bibliotecas. O palco lógico é 941 px de altura e se adapta a qualquer proporção (16:9, 16:10, 1024×600, ultralargas).

## Telas
Painel · Viagem (A/B) · Motor · Alertas · Configurações (aparência, unidades, fonte de dados, adaptador OBD2, veículo).
A referência visual tinha a aba "Info do Veículo"; no lugar entrou **Motor**, exigida no briefing.

## 1. Rodar no computador
```
cd web
python3 -m http.server 8080      # abra http://localhost:8080
```
Ou abra `web/index.html` direto no Chrome. Use `?nofs` na URL para não pedir tela cheia.
Inicia em **modo DEMONSTRAÇÃO** (valores simulados, etiqueta SIM). Em Configurações › Fonte de dados há cenários de teste: Parado, Superaquecimento, Bateria baixa, Falha OBD2. Em Alertas há botões de teste sonoro/visual.
Para testar o OBD2 sem carro: Configurações › Adaptador OBD2 › ponte **Emulado**, depois Fonte de dados › OBD2 real › Conectar.

## 2. Instalar na multimídia Android
**Opção A — app nativo (recomendada, necessária para a maioria dos ELM327):**
1. Instale o Android Studio e abra a pasta `android/`.
2. Build › Build APK(s). O Gradle usa `web/` como assets (sem cópia).
3. Copie o APK por pendrive, instale (permita fontes desconhecidas). Defina como app inicial se quiser.

**Opção B — só navegador (sem APK):** copie a pasta `web/` para o aparelho, hospede com um servidor local (ex.: app "Simple HTTP Server") e abra no Chrome → menu → *Adicionar à tela inicial*. Só leitura simulada ou ELM327 **BLE**.

## 3. Conectar o ELM327
1. Pareie o adaptador em Android › Bluetooth (senha 1234 ou 0000).
2. Abra o app › Configurações › Adaptador OBD2 › escolha o adaptador pareado.
3. Fonte de dados › **OBD2 real**. O app inicializa o ELM327, testa quais PIDs a ECU suporta e reconecta sozinho se cair.

**Web Bluetooth × nativo:** a maioria dos ELM327 baratos usa Bluetooth clássico (SPP), que o Web Bluetooth não acessa. Por isso há a ponte `AndroidOBD` (`android/.../BtBridge.kt`). Web Bluetooth só serve para adaptadores BLE e exige https ou localhost.

## Dados reais, simulados e indisponíveis
Sem etiqueta = lido da ECU · **SIM** simulado · **EST** estimado · **N/D** a ECU não informa. Nenhum valor é inventado: PIDs não suportados aparecem como indisponíveis. Marcha, consumo (sem MAF) e nível de combustível (sem PID 2F) são estimativas e marcados como tal.

## Arquitetura
```
web/js/core.js        barramento, catálogo de PIDs, CC.data (valor + qualidade)
web/js/config.js      configurações persistentes
web/js/derived.js     consumo, autonomia, marcha estimada
web/js/alerts.js      alertas com histerese, banner e som
web/js/sources/       demo.js | obd.js + elm327.js + transport-{bridge,webbluetooth,emulator}.js
web/js/ui/            mostradores e telas (só leem CC.data)
web/assets/cerato.png foto do carro (PNG com fundo transparente — troque pelo seu para mudar)
android/              WebView + ponte Bluetooth clássico
tests/shots.js        capturas Playwright em várias resoluções
```
Trocar demo ↔ OBD2 é só `CC.app.setSource()`; a interface não muda.

## Pontos a conferir no carro
Não foi possível testar com o veículo real. Verifique: capacidade do tanque (50 L é suposição), circunferência do pneu, quais PIDs a ECU responde (PID 42/2F/10 podem faltar) e o protocolo (automático costuma servir).
