// Captura telas em várias proporções. Uso: node shots.js <saida> [url]
const { chromium } = require('playwright');
const out = process.argv[2] || '/tmp/shots';
const base = process.argv[3] || 'file:///home/claude/cerato-cockpit/web/index.html?nofs';
const sizes = JSON.parse(process.env.SIZES || '[[1672,941,"16x9"]]');
const screens = (process.env.SCREENS || 'dash,trip,engine,alerts,settings').split(',');
(async () => {
  const b = await chromium.launch();
  const errs = [];
  for (const [w, h, n] of sizes) {
    const p = await b.newPage({ viewport: { width: w, height: h } });
    p.on('pageerror', (e) => errs.push(n + ' ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error') errs.push(n + ' console: ' + m.text()); });
    await p.goto(base); await p.waitForTimeout(6000);
    for (const s of screens) {
      await p.click('.tab[data-go=' + s + ']'); await p.waitForTimeout(900);
      await p.screenshot({ path: out + '/' + n + '_' + s + '.png' });
    }
    await p.close();
  }
  await b.close();
  console.log(errs.length ? 'ERROS:\n' + errs.join('\n') : 'sem erros JS');
})();
